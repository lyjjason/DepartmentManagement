import java.sql.SQLException;
import java.util.Vector;

public class EventFireStarter {

	
	public static void main(String[] args) throws SQLException {
		// TODO Auto-generated method stub
		EventFireGui g=new EventFireGui();
//		DeptHandler d=new DeptHandler();
//		Vector<String> input=new Vector<>();
//		input.add("101");
//		input.add("���빮");
//		input.add("����");
//		input.add("02-333-3333");
//		input.add("201");
//		
		//d.InsertRow(input);
		//d.deleteRow(100);
		//Vector<String> update=new Vector<>();
		//update.add("100");
		//update.add("");
//		update.add("����");
//		update.add("02-333-3333");
//		update.add("");
//		d.updateRow(100,update);
//		

		
//		Vector<Vector<String>> temp=d.showByOwner("202");
//		for(int i=0;i<temp.size();i++)
//		{
//			for(int j=0;j<temp.elementAt(i).size();j++)
//			{
//				System.out.println(temp.elementAt(i).elementAt(j));
//			}
//		}
//	}
//		Vector<String> key=new Vector<>();
//		key.add("101");
//		key.add("");
//		key.add("����");
//		key.add("");
//		key.add("");
//
//		Vector<Vector<String>> temp=d.searchWithManyKeywords(key);
//		for(int i=0;i<temp.size();i++)
//			{
//				for(int j=0;j<temp.elementAt(i).size();j++)
//				{
//					System.out.println(temp.elementAt(i).elementAt(j));
//				}
//			}
//
	}
}
