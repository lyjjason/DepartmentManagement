import java.sql.*;
import java.util.Vector;
public class StoreEmployeesHandler {

	private Connection conn;
	private Statement stmt;
	private jdbc db;
	public StoreEmployeesHandler()
	{
		db=new jdbc();
		conn=db.getCon();
		stmt=null;
	}
	public void InsertRow(Vector<String> input) throws SQLException//���� ���� ���� ���� ���� ���� row�� ���� ���̺��� �߰�
	{
		stmt=conn.createStatement();
		String query="INSERT INTO StoreEmployees(SEmployee_id, SEmployee_name, SSalary, SSalary, SRANK, SPerformance) VALUES(";
		query=query+input.elementAt(0)+",'"+input.elementAt(1)+"','"+input.elementAt(2)+"','"+input.elementAt(3)+"',"+input.elementAt(4)+"',"+input.elementAt(5)+")";
		stmt.executeQuery(query);
			System.out.println(query+" Executed");
		stmt.close();
	}
	public void deleteRow(int num) throws SQLException// ���� ���̵� ���� ���� ���̵� ���� row�� ���� ���̺����� ����
	{
		stmt=conn.createStatement();
		String query="DELETE FROM StoreEmployeesstores WHERE SEmployee_id=";
		query=query+num;
		stmt.executeQuery(query);
		System.out.println(query+" Executed");
		stmt.close();
		
	}
	public void updateRow(int num, Vector<String> input) throws SQLException// ���� ���� ������ row update.query�� , �־��ִ� ��� �����ϱ�?=> , �� ������ ����� �� query�� �ν��� ���Ѵ�!
	{
		stmt=conn.createStatement();
		String query="UPDATE StoreEmployees SET";
		for(int i=0;i<input.size();i++)
		{
			switch(i)
			{
			case 1:{
				if(!input.elementAt(i).equals(""))
				{
					query=query+" SEmployee_name='"+input.elementAt(i)+"'";
					int count=0;
					for(int j=i+1;j<input.size();j++)
					{
						if(!input.elementAt(j).equals(""))
							count++;
					}
					if(count!=0)
					{
						query=query+",";
					}
				
				}
				
				break;
			}
			case 2:
			{
				if(!input.elementAt(i).equals(""))
				{
					query=query+" SSalary='"+input.elementAt(i)+"'";
					int count=0;
					for(int j=i+1;j<input.size();j++)
					{
						if(!input.elementAt(j).equals(""))
							count++;
					}
					if(count!=0)
					{
						query=query+",";
					}
				}
				
				break;
			}
			case 3:
			{
				if(!input.elementAt(i).equals(""))
				{
					query=query+" SEMAIL='"+input.elementAt(i)+"'";
					if(!input.elementAt(4).equals(""))
					{
						query=query+",";
					}
				}
				break;
			}
			case 4:
			{
				if(!input.elementAt(i).equals(""))
				{
					query=query+" SRANK="+input.elementAt(i);
				}
				break;
			}
			case 5:
			{
				if(!input.elementAt(i).equals(""))
				{
					query=query+" SPerformance="+input.elementAt(i);
				}
				break;
			}
			}
		}
		query=query+" WHERE SEmployee_id="+num;
		stmt.executeQuery(query);
		System.out.println(query+" Executed");
		stmt.close();
		
	}
	public Vector<Vector<String>> showAllStoreEmployees() throws SQLException
	{
		
		Vector<Vector<String>> toRet=new Vector<>();
		stmt=conn.createStatement();
		ResultSet rs=stmt.executeQuery("SELECT* FROM StoreEmployees");
		while(rs.next())
		{
			Vector<String> temp=new Vector<>();
			temp.add(rs.getString("SEmployee_id"));
			temp.add(rs.getString("SEmployee_name"));
			temp.add(rs.getString("SSalary"));
			temp.add(rs.getString("SEMAIL"));
			temp.add(rs.getString("SRANK"));
			temp.add(rs.getString("SPerformance"));
			toRet.add(temp);
		}
		stmt.close();
		return toRet;
	}
	public Vector<Vector<String>> showBySEmployee_name(String SEmployee_name) throws SQLException
	{
		
		Vector<Vector<String>> toRet=new Vector<>();
		stmt=conn.createStatement();
		ResultSet rs=stmt.executeQuery("SELECT* FROM StoreEmployees WHERE SEmployee_name LIKE '"+SEmployee_name+"'");
		while(rs.next())
		{
			Vector<String> temp=new Vector<>();
			temp.add(rs.getString("SEmployee_id"));
			temp.add(rs.getString("SEmployee_name"));
			temp.add(rs.getString("SSalary"));
			temp.add(rs.getString("SEMAIL"));
			temp.add(rs.getString("SRANK"));
			temp.add(rs.getString("SPerformance"));
			toRet.add(temp);
		}
		stmt.close();
		return toRet;
	}
	public Vector<Vector<String>> showBySSalary(String SSalary) throws SQLException
	{
		
		Vector<Vector<String>> toRet=new Vector<>();
		stmt=conn.createStatement();
		ResultSet rs=stmt.executeQuery("SELECT* FROM StoreEmployees WHERE SSalary LIKE '"+SSalary+"'");
		while(rs.next())
		{
			Vector<String> temp=new Vector<>();
			temp.add(rs.getString("SEmployee_id"));
			temp.add(rs.getString("SEmployee_name"));
			temp.add(rs.getString("SSalary"));
			temp.add(rs.getString("SEMAIL"));
			temp.add(rs.getString("SRANK"));
			temp.add(rs.getString("SPerformance"));
			toRet.add(temp);
		}
		stmt.close();
		return toRet;
	}
	public Vector<Vector<String>> showBySEMAIL(String SEMAIL) throws SQLException
	{
		
		Vector<Vector<String>> toRet=new Vector<>();
		stmt=conn.createStatement();
		ResultSet rs=stmt.executeQuery("SELECT* FROM StoreEmployees WHERE SEMAIL LIKE '"+SEMAIL+"'");
		while(rs.next())
		{
			Vector<String> temp=new Vector<>();
			temp.add(rs.getString("SEmployee_id"));
			temp.add(rs.getString("SEmployee_name"));
			temp.add(rs.getString("SSalary"));
			temp.add(rs.getString("SEMAIL"));
			temp.add(rs.getString("SRANK"));
			temp.add(rs.getString("SPerformance"));
			toRet.add(temp);
		}
		stmt.close();
		return toRet;
	}
	public Vector<Vector<String>> showBySRANK(String SRANK) throws SQLException
	{
		
		Vector<Vector<String>> toRet=new Vector<>();
		stmt=conn.createStatement();
		ResultSet rs=stmt.executeQuery("SELECT* FROM StoreEmployees WHERE SRANK='"+SRANK+"'");
		while(rs.next())
		{
			Vector<String> temp=new Vector<>();
			temp.add(rs.getString("SEmployee_id"));
			temp.add(rs.getString("SEmployee_name"));
			temp.add(rs.getString("SSalary"));
			temp.add(rs.getString("SEMAIL"));
			temp.add(rs.getString("SRANK"));
			temp.add(rs.getString("SPerformance"));
			toRet.add(temp);
		}
		stmt.close();
		return toRet;
	}
	public Vector<Vector<String>> showBySPerformance(String SPerformance) throws SQLException
	{
		
		Vector<Vector<String>> toRet=new Vector<>();
		stmt=conn.createStatement();
		ResultSet rs=stmt.executeQuery("SELECT* FROM StoreEmployees WHERE SPerformance='"+SPerformance+"'");
		while(rs.next())
		{
			Vector<String> temp=new Vector<>();
			temp.add(rs.getString("SEmployee_id"));
			temp.add(rs.getString("SEmployee_name"));
			temp.add(rs.getString("SSalary"));
			temp.add(rs.getString("SEMAIL"));
			temp.add(rs.getString("SRANK"));
			temp.add(rs.getString("SPerformance"));
			toRet.add(temp);
		}
		stmt.close();
		return toRet;
	}
	public Vector<Vector<String>> searchWithManyKeywords(Vector<String> input) throws SQLException
	{ 
		Vector<Vector<String>> toRet=new Vector<>();
		stmt=conn.createStatement();
		String query="SELECT* FROM StoreEmployees WHERE ";
		for(int i=0;i<input.size();i++)
		{
			switch(i)
			{
			case 0:
			{
				if(!input.elementAt(i).equals(""))
				{
				query=query+"SEmployee_id="+input.elementAt(i);
				int count=0;
				for(int j=i+1;j<input.size();j++)
				{
					if(!input.elementAt(j).equals(""))
						count++;
				}
				if(count!=0)
				{
					query=query+"AND";
				}
				}
				break;
			}
			case 1:{
				if(!input.elementAt(i).equals(""))
				{
					query=query+"SEmployee_name LIKE '"+input.elementAt(i)+"'";
					int count=0;
					for(int j=i+1;j<input.size();j++)
					{
						if(!input.elementAt(j).equals(""))
							count++;
					}
					if(count!=0)
					{
						query=query+"AND";
					}
					}
				break;
			}
			case 2:
			{
				if(!input.elementAt(i).equals(""))
				{
					query=query+"SSalary ="+input.elementAt(i);
					int count=0;
					for(int j=i+1;j<input.size();j++)
					{
						if(!input.elementAt(j).equals(""))
							count++;
					}
					if(count!=0)
					{
						query=query+"AND";
					}
				}
				
				break;
			}
			case 3:
			{
				if(!input.elementAt(i).equals(""))
				{
					query=query+"SEMAIL LIKE '"+input.elementAt(i)+"'";
					if(!input.elementAt(4).equals(""))
					{
						query=query+"AND";
					}
				}
				break;
			}
			case 4:
			{
				if(!input.elementAt(i).equals(""))
				{
					query=query+"SRANK LIKE '"+input.elementAt(i)+"'";
					if(!input.elementAt(4).equals(""))
					{
						query=query+"AND";
					}
				}
				break;
			}
			case 5:
			{
				if(!input.elementAt(i).equals(""))
				{
				query=query+"SPerformance ="+input.elementAt(i);
				int count=0;
				for(int j=i+1;j<input.size();j++)
				{
					if(!input.elementAt(j).equals(""))
						count++;
				}
				if(count!=0)
				{
					query=query+"AND";
				}
				}
				break;
			}
			}
		}
		ResultSet rs=stmt.executeQuery(query);
		while(rs.next())
		{
			Vector<String> temp=new Vector<>();
			temp.add(rs.getString("DEPARTMENT_ID"));
			temp.add(rs.getString("NAME"));
			temp.add(rs.getString("CITY"));
			temp.add(rs.getString("CALL_NUM"));
			temp.add(rs.getString("OWNER"));
			toRet.add(temp);
		}
		return toRet;
	}
	public void finalize() throws SQLException
	{
		stmt.close();
		conn.close();
	}
}
