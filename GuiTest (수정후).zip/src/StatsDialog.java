import javax.swing.*;
import java.awt.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.sql.*;

public class StatsDialog extends JDialog {

	private JPanel pane;
	private JPanel chartpane;
	private GridLayout grid;
	private JButton showcity;
	private JButton showage;
	private JButton showclients;
	public StatsDialog(JFrame frame)
	{
		super(frame);
		setTitle("Database Statistics Menu");
		pane=new JPanel();
		chartpane=new JPanel();
		setLayout(new GridLayout(2, 1,50,200));
		grid=new GridLayout(1,3,70,70);
		pane.setLayout(grid);
		showcity=new JButton("���ú� ���� ���");
		showage=new JButton("���� ���� �� ���ɴ� ���");
		showclients=new JButton("������ ���� �� ���");
		pane.add(showcity);
		pane.add(showage);
		pane.add(showclients);
		add(pane);
		setSize(700, 500);
		setDefaultCloseOperation(JFrame.DISPOSE_ON_CLOSE);
		ActionListener listner=new ActionListener() {
			
			@Override
			public void actionPerformed(ActionEvent e) {
				// TODO Auto-generated method stub
				Object source=e.getSource();
				if(source==showcity)
				{
					
				}
				else if(source==showage)
				{
					
				}
				else if(source==showclients)
				{
					
				}
			}
		};
		
		
		
	}
}
