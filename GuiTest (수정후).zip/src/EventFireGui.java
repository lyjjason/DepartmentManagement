import java.awt.*;
import java.awt.event.*;
import java.io.File;
import java.io.IOException;

import javax.imageio.ImageIO;
import javax.swing.*;
import java.sql.*;

public class EventFireGui extends JFrame
{
	private DBEditDialog editd;
	private StatsDialog stat;
	public EventFireGui() throws SQLException{
	
		editd=new DBEditDialog(this);
		stat=new StatsDialog(this);
		JPanel panel=new JPanel();
		JButton start=new JButton("�����ͺ��̽� ����");
		JButton ave=new JButton("��� ����");
		JButton end=new JButton("����");
		setTitle("Database Project");
//		String filename=".\\resources\\noun_100615_cc.png";
//		Image img=ImageIO.read(new File(filename));
//		start.setIcon(new ImageIcon(img));
		ActionListener listner=new ActionListener() {
			
			@Override
			public void actionPerformed(ActionEvent e) {
				Object source=e.getSource();
				if(source==start)
				{
					editd.setVisible(true);
				}
				else if(source==ave)
				{
					stat.setVisible(true);
				}
				else if(source==end)
				{
					dispose();
				}
				
			}
		};
		start.addActionListener(listner);
		ave.addActionListener(listner);
		end.addActionListener(listner);
		GridLayout grid=new GridLayout(1, 3);
		grid.addLayoutComponent("start", start);
		grid.addLayoutComponent("ave", ave);
		grid.addLayoutComponent("end", end);
		panel.setLayout(grid);
		panel.add(start);
		panel.add(ave);
		panel.add(end);
		add(panel);
		setDefaultCloseOperation(JFrame.DISPOSE_ON_CLOSE);
		setSize(500,250);
		setVisible(true);
		
	}
}
