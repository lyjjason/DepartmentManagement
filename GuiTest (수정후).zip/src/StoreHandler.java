import java.sql.*;
import java.util.Vector;
public class StoreHandler {

	private Connection conn;
	private Statement stmt;
	private jdbc db;
	public StoreHandler()
	{
		db=new jdbc();
		conn=db.getCon();
		stmt=null;
	}
	public void InsertRow(Vector<String> input) throws SQLException//���� ���� ���� ���� ���� ���� row�� ���� ���̺��� �߰�
	{
		stmt=conn.createStatement();
		String query="INSERT INTO store(Store_id, Store_DepartmentID, Store_Name , Store_City , Store_Call_num ) VALUES(";
		query=query+input.elementAt(0)+",'"+input.elementAt(1)+"','"+input.elementAt(2)+"','"+input.elementAt(3)+"',"+input.elementAt(4)+")";
		stmt.executeQuery(query);
			System.out.println(query+" Executed");
		stmt.close();
	}
	public void deleteRow(int num) throws SQLException// ���� ���̵� ���� ���� ���̵� ���� row�� ���� ���̺����� ����
	{
		stmt=conn.createStatement();
		String query="DELETE FROM store WHERE Store_id =";
		query=query+num;
		stmt.executeQuery(query);
		System.out.println(query+" Executed");
		stmt.close();
		
	}
	public void updateRow(int num, Vector<String> input) throws SQLException// ���� ���� ������ row update.query�� , �־��ִ� ��� �����ϱ�?=> , �� ������ ����� �� query�� �ν��� ���Ѵ�!
	{
		stmt=conn.createStatement();
		String query="UPDATE store SET";
		for(int i=0;i<input.size();i++)
		{
			switch(i)
			{
			case 1:{
				if(!input.elementAt(i).equals(""))
				{
					query=query+" Store_DepartmentID='"+input.elementAt(i)+"'";
					int count=0;
					for(int j=i+1;j<input.size();j++)
					{
						if(!input.elementAt(j).equals(""))
							count++;
					}
					if(count!=0)
					{
						query=query+",";
					}
				
				}
				
				break;
			}
			case 2:
			{
				if(!input.elementAt(i).equals(""))
				{
					query=query+" Store_Name='"+input.elementAt(i)+"'";
					int count=0;
					for(int j=i+1;j<input.size();j++)
					{
						if(!input.elementAt(j).equals(""))
							count++;
					}
					if(count!=0)
					{
						query=query+",";
					}
				}
				
				break;
			}
			case 3:
			{
				if(!input.elementAt(i).equals(""))
				{
					query=query+" Store_City='"+input.elementAt(i)+"'";
					if(!input.elementAt(4).equals(""))
					{
						query=query+",";
					}
				}
				break;
			}
			case 4:
			{
				if(!input.elementAt(i).equals(""))
				{
					query=query+" Store_Call_num="+input.elementAt(i);
				}
				break;
			}
			}
		}
		query=query+" WHERE Store_id="+num;
		stmt.executeQuery(query);
		System.out.println(query+" Executed");
		stmt.close();
		
	}
	public Vector<Vector<String>> showAllStore() throws SQLException
	{
		
		Vector<Vector<String>> toRet=new Vector<>();
		stmt=conn.createStatement();
		ResultSet rs=stmt.executeQuery("SELECT* FROM store");
		while(rs.next())
		{
			Vector<String> temp=new Vector<>();
			temp.add(rs.getString("Store_id"));
			temp.add(rs.getString("Store_DepartmentID"));
			temp.add(rs.getString("Store_Name"));
			temp.add(rs.getString("Store_City"));
			temp.add(rs.getString("Store_Call_num"));
			toRet.add(temp);
		}
		stmt.close();
		return toRet;
	}
	public Vector<Vector<String>> showByStore_DepartmentID(String Store_DepartmentID) throws SQLException
	{
		
		Vector<Vector<String>> toRet=new Vector<>();
		stmt=conn.createStatement();
		ResultSet rs=stmt.executeQuery("SELECT* FROM store WHERE name LIKE '"+Store_DepartmentID+"'");
		while(rs.next())
		{
			Vector<String> temp=new Vector<>();
			temp.add(rs.getString("Store_id"));
			temp.add(rs.getString("Store_DepartmentID"));
			temp.add(rs.getString("Store_Name"));
			temp.add(rs.getString("Store_City"));
			temp.add(rs.getString("Store_Call_num"));
			toRet.add(temp);
		}
		stmt.close();
		return toRet;
	}
	public Vector<Vector<String>> showByStore_Name(String Store_Name) throws SQLException
	{
		
		Vector<Vector<String>> toRet=new Vector<>();
		stmt=conn.createStatement();
		ResultSet rs=stmt.executeQuery("SELECT* FROM store WHERE city LIKE '"+Store_Name+"'");
		while(rs.next())
		{
			Vector<String> temp=new Vector<>();
			temp.add(rs.getString("Store_id"));
			temp.add(rs.getString("Store_DepartmentID"));
			temp.add(rs.getString("Store_Name"));
			temp.add(rs.getString("Store_City"));
			temp.add(rs.getString("Store_Call_num"));
			toRet.add(temp);
		}
		stmt.close();
		return toRet;
	}
	public Vector<Vector<String>> showByStore_City(String Store_City) throws SQLException
	{
		
		Vector<Vector<String>> toRet=new Vector<>();
		stmt=conn.createStatement();
		ResultSet rs=stmt.executeQuery("SELECT* FROM store WHERE call_num LIKE '"+Store_City+"'");
		while(rs.next())
		{
			Vector<String> temp=new Vector<>();
			temp.add(rs.getString("Store_id"));
			temp.add(rs.getString("Store_DepartmentID"));
			temp.add(rs.getString("Store_Name"));
			temp.add(rs.getString("Store_City"));
			temp.add(rs.getString("Store_Call_num"));
			toRet.add(temp);
		}
		stmt.close();
		return toRet;
	}
	public Vector<Vector<String>> showByStore_Call_num(String Store_Call_num) throws SQLException
	{
		
		Vector<Vector<String>> toRet=new Vector<>();
		stmt=conn.createStatement();
		ResultSet rs=stmt.executeQuery("SELECT* FROM store WHERE owner='"+Store_Call_num+"'");
		while(rs.next())
		{
			Vector<String> temp=new Vector<>();
			temp.add(rs.getString("Store_id"));
			temp.add(rs.getString("Store_DepartmentID"));
			temp.add(rs.getString("Store_Name"));
			temp.add(rs.getString("Store_City"));
			temp.add(rs.getString("Store_Call_num"));
			toRet.add(temp);
		}
		stmt.close();
		return toRet;
	}
	public Vector<Vector<String>> searchWithManyKeywords(Vector<String> input) throws SQLException
	{ 
		Vector<Vector<String>> toRet=new Vector<>();
		stmt=conn.createStatement();
		String query="SELECT* FROM store WHERE ";
		for(int i=0;i<input.size();i++)
		{
			switch(i)
			{
			case 0:
			{
				if(!input.elementAt(i).equals(""))
				{
				query=query+"Store_id ="+input.elementAt(i);
				int count=0;
				for(int j=i+1;j<input.size();j++)
				{
					if(!input.elementAt(j).equals(""))
						count++;
				}
				if(count!=0)
				{
					query=query+"AND";
				}
				}
				break;
			}
			case 1:
			{
				if(!input.elementAt(i).equals(""))
				{
				query=query+"Store_DepartmentID="+input.elementAt(i);
				int count=0;
				for(int j=i+1;j<input.size();j++)
				{
					if(!input.elementAt(j).equals(""))
						count++;
				}
				if(count!=0)
				{
					query=query+"AND";
				}
				}
				break;
			}
			case 2:{
				if(!input.elementAt(i).equals(""))
				{
					query=query+"Store_Name LIKE '"+input.elementAt(i)+"'";
					int count=0;
					for(int j=i+1;j<input.size();j++)
					{
						if(!input.elementAt(j).equals(""))
							count++;
					}
					if(count!=0)
					{
						query=query+"AND";
					}
					}
				break;
			}
			case 3:
			{
				if(!input.elementAt(i).equals(""))
				{
					query=query+"Store_City LIKE '"+input.elementAt(i)+"'";
					int count=0;
					for(int j=i+1;j<input.size();j++)
					{
						if(!input.elementAt(j).equals(""))
							count++;
					}
					if(count!=0)
					{
						query=query+"AND";
					}
				}
				
				break;
			}			
			case 4:
			{
				if(!input.elementAt(i).equals(""))
				{
					query=query+" Store_Call_num="+input.elementAt(i);
				}
				break;
			}
			}
		}
		ResultSet rs=stmt.executeQuery(query);
		while(rs.next())
		{
			Vector<String> temp=new Vector<>();
			temp.add(rs.getString("Store_id"));
			temp.add(rs.getString("Store_DepartmentID"));
			temp.add(rs.getString("Store_Name"));
			temp.add(rs.getString("Store_City"));
			temp.add(rs.getString("Store_Call_num"));
			toRet.add(temp);
		}
		return toRet;
	}
	public void finalize() throws SQLException
	{
		stmt.close();
		conn.close();
	}
}
