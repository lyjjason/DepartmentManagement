import java.sql.*;
import java.util.Vector;
public class ClientHandler {

	private Connection conn;
	private Statement stmt;
	private jdbc db;
	public ClientHandler()
	{
		db=new jdbc();
		conn=db.getCon();
		stmt=null;
	}
	public void InsertRow(Vector<String> input) throws SQLException//���� ���� ���� ���� ���� ���� row�� ���� ���̺��� �߰�
	{
		stmt=conn.createStatement();
		String query="INSERT INTO Client(Client_id , Client_name , Client_email , Client_gender , Client_old, Client_grade ,Client_mileage) VALUES(";
		query=query+input.elementAt(0)+",'"+input.elementAt(1)+"','"+input.elementAt(2)+"','"+input.elementAt(3)+"',"+input.elementAt(4)+input.elementAt(5)+input.elementAt(6)+")";
		stmt.executeQuery(query);
			System.out.println(query+" Executed");
		stmt.close();
	}
	public void deleteRow(int num) throws SQLException// ���� ���̵� ���� ���� ���̵� ���� row�� ���� ���̺����� ����
	{
		stmt=conn.createStatement();
		String query="DELETE FROM Client WHERE Client_id=";
		query=query+num;
		stmt.executeQuery(query);
		System.out.println(query+" Executed");
		stmt.close();
		
	}
	public void updateRow(int num, Vector<String> input) throws SQLException// ���� ���� ������ row update.query�� , �־��ִ� ��� �����ϱ�?=> , �� ������ ����� �� query�� �ν��� ���Ѵ�!
	{
		stmt=conn.createStatement();
		String query="UPDATE Client SET";
		for(int i=0;i<input.size();i++)
		{
			switch(i)
			{
			case 1:{
				if(!input.elementAt(i).equals(""))
				{
					query=query+" Client_name='"+input.elementAt(i)+"'";
					int count=0;
					for(int j=i+1;j<input.size();j++)
					{
						if(!input.elementAt(j).equals(""))
							count++;
					}
					if(count!=0)
					{
						query=query+",";
					}
				
				}
				
				break;
			}
			case 2:
			{
				if(!input.elementAt(i).equals(""))
				{
					query=query+" Client_email='"+input.elementAt(i)+"'";
					int count=0;
					for(int j=i+1;j<input.size();j++)
					{
						if(!input.elementAt(j).equals(""))
							count++;
					}
					if(count!=0)
					{
						query=query+",";
					}
				}
				
				break;
			}
			case 3:
			{
				if(!input.elementAt(i).equals(""))
				{
					query=query+" Client_gender='"+input.elementAt(i)+"'";
					if(!input.elementAt(4).equals(""))
					{
						query=query+",";
					}
				}
				break;
			}
			case 4:
			{
				if(!input.elementAt(i).equals(""))
				{
					query=query+" Client_old="+input.elementAt(i);
				}
				break;
			}
			case 5:
			{
				if(!input.elementAt(i).equals(""))
				{
					query=query+" Client_grade="+input.elementAt(i);
				}
				break;
			}
			case 6:
			{
				if(!input.elementAt(i).equals(""))
				{
					query=query+" Client_mileage="+input.elementAt(i);
				}
				break;
			}
			
			}
		}
		query=query+" WHERE Client_id="+num;
		stmt.executeQuery(query);
		System.out.println(query+" Executed");
		stmt.close();
		
	}
	public Vector<Vector<String>> showAllClient() throws SQLException
	{
		
		Vector<Vector<String>> toRet=new Vector<>();
		stmt=conn.createStatement();
		ResultSet rs=stmt.executeQuery("SELECT* FROM client");
		while(rs.next())
		{
			Vector<String> temp=new Vector<>();
			temp.add(rs.getString("Client_id"));
			temp.add(rs.getString("Client_name"));
			temp.add(rs.getString("Client_gender"));
			temp.add(rs.getString("Client_old"));
			temp.add(rs.getString("Client_grade"));
			temp.add(rs.getString("Client_mileage"));
			toRet.add(temp);
		}
		stmt.close();
		return toRet;
	}
	public Vector<Vector<String>> showByClient_name(String Client_name) throws SQLException
	{
		
		Vector<Vector<String>> toRet=new Vector<>();
		stmt=conn.createStatement();
		ResultSet rs=stmt.executeQuery("SELECT* FROM client WHERE Client_name LIKE '"+Client_name+"'");
		while(rs.next())
		{
			Vector<String> temp=new Vector<>();
			temp.add(rs.getString("Client_id"));
			temp.add(rs.getString("Client_name"));
			temp.add(rs.getString("Client_gender"));
			temp.add(rs.getString("Client_old"));
			temp.add(rs.getString("Client_grade"));
			temp.add(rs.getString("Client_mileage"));
			toRet.add(temp);
		}
		stmt.close();
		return toRet;
	}
	public Vector<Vector<String>> showByCity(String Client_name) throws SQLException
	{
		
		Vector<Vector<String>> toRet=new Vector<>();
		stmt=conn.createStatement();
		ResultSet rs=stmt.executeQuery("SELECT* FROM client WHERE Client_name LIKE '"+Client_name+"'");
		while(rs.next())
		{
			Vector<String> temp=new Vector<>();
			temp.add(rs.getString("Client_id"));
			temp.add(rs.getString("Client_name"));
			temp.add(rs.getString("Client_gender"));
			temp.add(rs.getString("Client_old"));
			temp.add(rs.getString("Client_grade"));
			temp.add(rs.getString("Client_mileage"));
			toRet.add(temp);
		}
		stmt.close();
		return toRet;
	}
	public Vector<Vector<String>> showByClient_gender(String Client_gender) throws SQLException
	{
		
		Vector<Vector<String>> toRet=new Vector<>();
		stmt=conn.createStatement();
		ResultSet rs=stmt.executeQuery("SELECT* FROM client WHERE call_num LIKE '"+Client_gender+"'");
		while(rs.next())
		{
			Vector<String> temp=new Vector<>();
			temp.add(rs.getString("Client_id"));
			temp.add(rs.getString("Client_name"));
			temp.add(rs.getString("Client_gender"));
			temp.add(rs.getString("Client_old"));
			temp.add(rs.getString("Client_grade"));
			temp.add(rs.getString("Client_mileage"));
			toRet.add(temp);
		}
		stmt.close();
		return toRet;
	}
	public Vector<Vector<String>> showByClient_old(String Client_old) throws SQLException
	{
		
		Vector<Vector<String>> toRet=new Vector<>();
		stmt=conn.createStatement();
		ResultSet rs=stmt.executeQuery("SELECT* FROM client WHERE Client_old='"+Client_old+"'");
		while(rs.next())
		{
			Vector<String> temp=new Vector<>();
			temp.add(rs.getString("Client_id"));
			temp.add(rs.getString("Client_name"));
			temp.add(rs.getString("Client_gender"));
			temp.add(rs.getString("Client_old"));
			temp.add(rs.getString("Client_grade"));
			temp.add(rs.getString("Client_mileage"));
			toRet.add(temp);
		}
		stmt.close();
		return toRet;
	}
	public Vector<Vector<String>> showByClient_grade(String Client_grade) throws SQLException
	{
		
		Vector<Vector<String>> toRet=new Vector<>();
		stmt=conn.createStatement();
		ResultSet rs=stmt.executeQuery("SELECT* FROM client WHERE Client_grade='"+Client_grade+"'");
		while(rs.next())
		{
			Vector<String> temp=new Vector<>();
			temp.add(rs.getString("Client_id"));
			temp.add(rs.getString("Client_name"));
			temp.add(rs.getString("Client_gender"));
			temp.add(rs.getString("Client_old"));
			temp.add(rs.getString("Client_grade"));
			temp.add(rs.getString("Client_mileage"));
			toRet.add(temp);
		}
		stmt.close();
		return toRet;
	}
	public Vector<Vector<String>> showByClient_mileage(String Client_mileage) throws SQLException
	{
		
		Vector<Vector<String>> toRet=new Vector<>();
		stmt=conn.createStatement();
		ResultSet rs=stmt.executeQuery("SELECT* FROM client WHERE Client_mileage='"+Client_mileage+"'");
		while(rs.next())
		{
			Vector<String> temp=new Vector<>();
			temp.add(rs.getString("Client_id"));
			temp.add(rs.getString("Client_name"));
			temp.add(rs.getString("Client_gender"));
			temp.add(rs.getString("Client_old"));
			temp.add(rs.getString("Client_grade"));
			temp.add(rs.getString("Client_mileage"));
			toRet.add(temp);
		}
		stmt.close();
		return toRet;
	}
	
	
	
	public Vector<Vector<String>> searchWithManyKeywords(Vector<String> input) throws SQLException
	{ 
		Vector<Vector<String>> toRet=new Vector<>();
		stmt=conn.createStatement();
		String query="SELECT* FROM client WHERE ";
		for(int i=0;i<input.size();i++)
		{
			switch(i)
			{
			case 0:
			{
				if(!input.elementAt(i).equals(""))
				{
				query=query+"Client_id="+input.elementAt(i);
				int count=0;
				for(int j=i+1;j<input.size();j++)
				{
					if(!input.elementAt(j).equals(""))
						count++;
				}
				if(count!=0)
				{
					query=query+"AND";
				}
				}
				break;
			}
			case 1:{
				if(!input.elementAt(i).equals(""))
				{
					query=query+"Client_name LIKE '"+input.elementAt(i)+"'";
					int count=0;
					for(int j=i+1;j<input.size();j++)
					{
						if(!input.elementAt(j).equals(""))
							count++;
					}
					if(count!=0)
					{
						query=query+"AND";
					}
					}
				break;
			}
			case 2:
			{
				if(!input.elementAt(i).equals(""))
				{
					query=query+"Client_email LIKE '"+input.elementAt(i)+"'";
					int count=0;
					for(int j=i+1;j<input.size();j++)
					{
						if(!input.elementAt(j).equals(""))
							count++;
					}
					if(count!=0)
					{
						query=query+"AND";
					}
				}
				
				break;
			}
			case 3:
			{
				if(!input.elementAt(i).equals(""))
				{
					query=query+"Client_gender LIKE '"+input.elementAt(i)+"'";
					if(!input.elementAt(4).equals(""))
					{
						query=query+"AND";
					}
				}
				break;
			}
			case 4:
			{
				if(!input.elementAt(i).equals(""))
				{
					query=query+" Client_old="+input.elementAt(i);
				}
				break;
			}
			case 5:
			{
				if(!input.elementAt(i).equals(""))
				{
					query=query+"Client_grade LIKE '"+input.elementAt(i)+"'";
					if(!input.elementAt(4).equals(""))
					{
						query=query+"AND";
					}
				}
				break;
			}
			case 6:
			{
				if(!input.elementAt(i).equals(""))
				{
					query=query+" Client_mileage="+input.elementAt(i);
				}
				break;
			}			
			}
		}
		ResultSet rs=stmt.executeQuery(query);
		while(rs.next())
		{
			Vector<String> temp=new Vector<>();
			temp.add(rs.getString("Client_id"));
			temp.add(rs.getString("Client_name"));
			temp.add(rs.getString("Client_gender"));
			temp.add(rs.getString("Client_old"));
			temp.add(rs.getString("Client_grade"));
			temp.add(rs.getString("Client_mileage"));
			toRet.add(temp);
		}
		return toRet;
	}
	public void finalize() throws SQLException
	{
		stmt.close();
		conn.close();
	}
}
