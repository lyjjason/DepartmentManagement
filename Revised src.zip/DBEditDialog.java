import javax.swing.*;
import javax.swing.event.ChangeEvent;
import javax.swing.event.ChangeListener;
import javax.swing.event.TableModelListener;
import javax.swing.table.AbstractTableModel;
import javax.swing.table.DefaultTableModel;
import javax.swing.table.TableModel;

import java.awt.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.awt.event.MouseAdapter;
import java.awt.event.MouseEvent;
import java.sql.*;
import java.util.Vector;

class DeptPanel extends JPanel{
	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;
	private DeptHandler d;
	private JScrollPane spane;
	private JPanel view;
	private JPanel insert;
	private JPanel update;
	private JPanel delete;
	private JPanel search;
	private JTabbedPane insidetab;
	private JTable table;
	private JLabel id;
	private JLabel name;
	private JLabel city;
	private JLabel call;
	private JLabel own;
	private JTextArea sid;
	private JTextArea sname;
	private JTextArea scall;
	private JTextArea sown;
	private JTextArea scity;
	private JTextField fid;
	private JTextField fname;
	private JTextField fcall;
	private JTextField fown;
	private JTextField fcity;	
	private JTextField fiid;
	private JTextField finame;
	private JTextField ficall;
	private JTextField fiown;
	private JTextField ficity;
	private JTextField todel;
	private JButton conf;
	private JButton conf2;
	private JButton del;
	private JTextField fsid;
	private JTextField fsname;
	private JTextField fscall;
	private JTextField fsown;
	private JTextField fscity;
	private JButton conf3;
	public DeptPanel() throws SQLException
	{
		insidetab=new JTabbedPane();
		d=new DeptHandler();
		Vector<Vector<String>> data=d.showAllDepts();
		Vector<String> title=new Vector<>();
		title.add("���� Id");
		title.add("������");
		title.add("����");
		title.add("����ó");
		title.add("������ Id");
		DefaultTableModel model=new DefaultTableModel(title,0);
		for(int i=0;i<data.size();i++)
		{
			model.addRow(data.elementAt(i));
		}
		table=new JTable(model);
		spane=new JScrollPane(table);
		setLayout(new GridLayout(1,2));
		view=new JPanel();
		update=new JPanel();
		insert=new JPanel();
		delete=new JPanel();
		search=new JPanel();
		view.setLayout(new BoxLayout(view, BoxLayout.Y_AXIS));
		update.setLayout(new BoxLayout(update, BoxLayout.Y_AXIS));
		insert.setLayout(new BoxLayout(insert, BoxLayout.Y_AXIS));
		search.setLayout(new BoxLayout(search, BoxLayout.Y_AXIS));
		delete.setLayout(new FlowLayout());
		
		id=new JLabel("Id: ");
		name=new JLabel("������: ");
		city=new JLabel("����: ");
		call=new JLabel("����ó: ");
		own=new JLabel("������: ");
		
		sid=new JTextArea();
		sname=new JTextArea();
		scity=new JTextArea();
		scall=new JTextArea();
		sown=new JTextArea();
		
		view.add(id);
		view.add(sid);
		view.add(name);
		view.add(sname);
		view.add(city);
		view.add(scity);
		view.add(call);
		view.add(scall);
		view.add(own);
		view.add(sown);

		
		fid=new JTextField();
		fname=new JTextField();
		fcity=new JTextField();
		fcall=new JTextField();
		fown=new JTextField();
		
		JLabel uid=new JLabel("Id: ");
		JLabel un=new JLabel("������: ");
		JLabel ucity=new JLabel("����: ");
		JLabel ucall=new JLabel("����ó: ");
		JLabel uown=new JLabel("������: ");
		
		conf=new JButton("Configure");
		update.add(uid);
		update.add(fid);
		update.add(un);
		update.add(fname);
		update.add(ucity);
		update.add(fcity);
		update.add(ucall);
		update.add(fcall);
		update.add(uown);
		update.add(fown);
		update.add(conf);
		
		JLabel iid=new JLabel("Id: ");
		JLabel in=new JLabel("������: ");
		JLabel icity=new JLabel("����: ");
		JLabel icall=new JLabel("����ó: ");
		JLabel iown=new JLabel("������: ");
		
		conf2=new JButton("Configure");
		fiid=new JTextField();
		finame=new JTextField();
		ficity=new JTextField();
		ficall=new JTextField();
		fiown=new JTextField();
		insert.add(iid);
		insert.add(fiid);
		insert.add(in);
		insert.add(finame);
		insert.add(icity);
		insert.add(ficity);
		insert.add(icall);
		insert.add(ficall);
		insert.add(iown);
		insert.add(fiown);
		insert.add(conf2);
		
		JLabel delid=new JLabel("Insert Id: ");
		todel=new JTextField(20);
		del=new JButton("Delete");
		delete.add(delid);
		delete.add(todel);
		delete.add(del);
		
		JLabel sid=new JLabel("Id: ");
		JLabel sin=new JLabel("������: ");
		JLabel scity=new JLabel("����: ");
		JLabel scall=new JLabel("����ó: ");
		JLabel sown=new JLabel("������: ");
		
		fsid=new JTextField();
		fsname=new JTextField();
		fscity=new JTextField();
		fscall=new JTextField();
		fsown=new JTextField();
		conf3=new JButton("Configure");
		search.add(sid);
		search.add(fsid);
		search.add(sin);
		search.add(fsname);
		search.add(scity);
		search.add(fscity);
		search.add(scall);
		search.add(fscall);
		search.add(sown);
		search.add(fsown);
		search.add(conf3);
		insidetab.add("View", view);
		insidetab.add("Update", update);
		insidetab.add("Insert",insert);
		insidetab.add("Delete", delete);
		insidetab.add("Search",search);
		ChangeListener change=new ChangeListener() {
			
			@Override
			public void stateChanged(ChangeEvent e) {
				// TODO Auto-generated method stub
				Vector<String> title=new Vector<>();
				Vector<Vector<String>> data = new Vector<>();
				try {
					data = d.showAllDepts();
				} catch (SQLException e1) {
					// TODO Auto-generated catch block
					e1.printStackTrace();
				}
				title.add("���� Id");
				title.add("������");
				title.add("����");
				title.add("����ó");
				title.add("������ Id");
				DefaultTableModel temp=new DefaultTableModel(title, 0);
				for(int a=0;a<data.size();a++)
				{
					temp.addRow(data.elementAt(a));
				}
				table.setModel(temp);
				
			}
		};
		insidetab.addChangeListener(change);
		add(spane);
		add(insidetab);
		
	}
	public void ShowElement() throws SQLException
	{
		Vector<JTextArea> clist=new Vector<>();
		clist.add(sid);
		clist.add(sname);
		clist.add(scity);
		clist.add(scall);
		clist.add(sown);
		table.addMouseListener(new MouseAdapter() {
			public void mouseClicked(MouseEvent e)
			{
				int row=table.getSelectedRow();
				for(int i=0;i<table.getColumnCount();i++)
				{
					Object a=table.getValueAt(row, i);
					String s=a.toString();
					clist.elementAt(i).setText(s);
					System.out.println(s);
				}
			}
		});
	}
	public void UpdateElement() throws SQLException
	{
		Vector<JTextField> clist=new Vector<>();
		
		conf.addMouseListener(new MouseAdapter() {
			public void mouseClicked(MouseEvent e)
			{
				clist.add(fid);
				clist.add(fname);
				clist.add(fcity);
				clist.add(fcall);
				clist.add(fown);
				Vector<Vector<String>> data=new Vector<>();
				Vector<String> input=new Vector<>();
				for(int i=0;i<table.getColumnCount();i++)
				{
					String s=clist.elementAt(i).getText();
					input.add(s);
				}
				int count=0;
				for(int i=0;i<input.size();i++)
				{
					String a=input.elementAt(i);
					if(a.equals(""))
						count++;
				}
				if(count!=input.size()-1)
				{
				int num=Integer.parseInt(input.elementAt(0));
				try {
					d.updateRow(num, input);
				} catch (SQLException e1) {
					e1.printStackTrace();
				}
				try {
					data = d.showAllDepts();
				} catch (SQLException e1) {
					e1.printStackTrace();
				}
				}
				try {
					data=d.showAllDepts();
				} catch (SQLException e1) {
					// TODO Auto-generated catch block
					e1.printStackTrace();
				}
				Vector<String> title=new Vector<>();
				title.add("���� Id");
				title.add("������");
				title.add("����");
				title.add("����ó");
				title.add("������ Id");
				DefaultTableModel temp=new DefaultTableModel(title, 0);
				for(int a=0;a<data.size();a++)
				{
					temp.addRow(data.elementAt(a));
				}
				table.setModel(temp);
			}
		});
		
	}
	public void InsertRow()	throws SQLException
	{
		Vector<JTextField> clist=new Vector<>();
		
		conf2.addMouseListener(new MouseAdapter() {
			public void mouseClicked(MouseEvent e)
			{
				clist.add(fiid);
				clist.add(finame);
				clist.add(ficity);
				clist.add(ficall);
				clist.add(fiown);
				Vector<Vector<String>> data=new Vector<>();
				Vector<String> input=new Vector<>();
				for(int i=0;i<table.getColumnCount();i++)
				{
					String s=clist.elementAt(i).getText();
					input.add(s);
				}
				int count=0;
				for(int i=0;i<input.size();i++)
				{
					String a=input.elementAt(i);
					if(a.equals(""))
						count++;
				}
				if(count!=input.size()-1)
				{
				int num=Integer.parseInt(input.elementAt(0));
				try {
					d.InsertRow(input);
				} catch (SQLException e1) {
					e1.printStackTrace();
				}
				try {
					data = d.showAllDepts();
				} catch (SQLException e1) {
					e1.printStackTrace();
				}
				}
				try {
					data=d.showAllDepts();
				} catch (SQLException e1) {
					// TODO Auto-generated catch block
					e1.printStackTrace();
				}
				Vector<String> title=new Vector<>();
				title.add("���� Id");
				title.add("������");
				title.add("����");
				title.add("����ó");
				title.add("������ Id");
				DefaultTableModel temp=new DefaultTableModel(title, 0);
				for(int a=0;a<data.size();a++)
				{
					temp.addRow(data.elementAt(a));
				}
				table.setModel(temp);
			}
		});
	}
	public void deleteElement() throws SQLException
	{
		
		del.addMouseListener(new MouseAdapter() {
			public void mouseClicked(MouseEvent e)
			{
				Vector<Vector<String>> data=new Vector<>();
				String s=todel.getText();
				int num=Integer.parseInt(s);
				try {
					d.deleteRow(num);
				} catch (SQLException e1) {
					e1.printStackTrace();
				}
				try {
					data = d.showAllDepts();
				} catch (SQLException e1) {
					e1.printStackTrace();
				}
				try {
					data=d.showAllDepts();
				} catch (SQLException e1) {
					// TODO Auto-generated catch block
					e1.printStackTrace();
				}
				Vector<String> title=new Vector<>();
				title.add("���� Id");
				title.add("������");
				title.add("����");
				title.add("����ó");
				title.add("������ Id");
				DefaultTableModel temp=new DefaultTableModel(title, 0);
				for(int a=0;a<data.size();a++)
				{
					temp.addRow(data.elementAt(a));
				}
				table.setModel(temp);
			}
		});
}
	public void searchItem() throws SQLException
	{
		Vector<JTextField> clist=new Vector<>();
		conf3.addMouseListener(new MouseAdapter() {
			public void mouseClicked(MouseEvent e)
			{
				clist.add(fsid);
				clist.add(fsname);
				clist.add(fscity);
				clist.add(fscall);
				clist.add(fsown);
				Vector<Vector<String>> data=new Vector<>();
				Vector<String> input=new Vector<>();
				for(int i=0;i<table.getColumnCount();i++)
				{
					String s=clist.elementAt(i).getText();
					input.add(s);
				}
				try {
					data = d.searchWithManyKeywords(input);
				} catch (SQLException e1) {
					e1.printStackTrace();
				}
				try {
					data = d.searchWithManyKeywords(input);
				} catch (SQLException e1) {
					// TODO Auto-generated catch block
					e1.printStackTrace();
				}
				Vector<String> title=new Vector<>();
				title.add("���� Id");
				title.add("������");
				title.add("����");
				title.add("����ó");
				title.add("������ Id");
				DefaultTableModel temp=new DefaultTableModel(title, 0);
				for(int a=0;a<data.size();a++)
				{
					temp.addRow(data.elementAt(a));
				}
				table.setModel(temp);
			}
		});
	}
}


class StorePanel extends JPanel{
	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;
	private DeptHandler d;
	private JScrollPane spane;
	private JPanel view;
	private JPanel insert;
	private JPanel update;
	private JPanel delete;
	private JPanel search;
	private JTabbedPane insidetab;
	private JTable table;
	private JLabel id;
	private JLabel name;
	private JLabel city;
	private JLabel call;
	private JLabel own;
	private JTextArea sid;
	private JTextArea sname;
	private JTextArea scall;
	private JTextArea sown;
	private JTextArea scity;
	private JTextField fid;
	private JTextField fname;
	private JTextField fcall;
	private JTextField fown;
	private JTextField fcity;	
	private JTextField fiid;
	private JTextField finame;
	private JTextField ficall;
	private JTextField fiown;
	private JTextField ficity;
	private JTextField todel;
	private JButton conf;
	private JButton conf2;
	private JButton del;
	private JTextField fsid;
	private JTextField fsname;
	private JTextField fscall;
	private JTextField fsown;
	private JTextField fscity;
	private JButton conf3;
	public StorePanel() throws SQLException
	{
		insidetab=new JTabbedPane();
		d=new DeptHandler();
		Vector<Vector<String>> data=d.showAllDepts();
		Vector<String> title=new Vector<>();
		title.add("���� Id");
		title.add("������");
		title.add("����");
		title.add("����ó");
		title.add("������ Id");
		DefaultTableModel model=new DefaultTableModel(title,0);
		for(int i=0;i<data.size();i++)
		{
			model.addRow(data.elementAt(i));
		}
		table=new JTable(model);
		spane=new JScrollPane(table);
		setLayout(new GridLayout(1,2));
		view=new JPanel();
		update=new JPanel();
		insert=new JPanel();
		delete=new JPanel();
		search=new JPanel();
		view.setLayout(new BoxLayout(view, BoxLayout.Y_AXIS));
		update.setLayout(new BoxLayout(update, BoxLayout.Y_AXIS));
		insert.setLayout(new BoxLayout(insert, BoxLayout.Y_AXIS));
		search.setLayout(new BoxLayout(search, BoxLayout.Y_AXIS));
		delete.setLayout(new FlowLayout());
		
		id=new JLabel("Id: ");
		name=new JLabel("������: ");
		city=new JLabel("����: ");
		call=new JLabel("����ó: ");
		own=new JLabel("������: ");
		
		sid=new JTextArea();
		sname=new JTextArea();
		scity=new JTextArea();
		scall=new JTextArea();
		sown=new JTextArea();
		
		view.add(id);
		view.add(sid);
		view.add(name);
		view.add(sname);
		view.add(city);
		view.add(scity);
		view.add(call);
		view.add(scall);
		view.add(own);
		view.add(sown);

		
		fid=new JTextField();
		fname=new JTextField();
		fcity=new JTextField();
		fcall=new JTextField();
		fown=new JTextField();
		
		JLabel uid=new JLabel("Id: ");
		JLabel un=new JLabel("������: ");
		JLabel ucity=new JLabel("����: ");
		JLabel ucall=new JLabel("����ó: ");
		JLabel uown=new JLabel("������: ");
		
		conf=new JButton("Configure");
		update.add(uid);
		update.add(fid);
		update.add(un);
		update.add(fname);
		update.add(ucity);
		update.add(fcity);
		update.add(ucall);
		update.add(fcall);
		update.add(uown);
		update.add(fown);
		update.add(conf);
		
		JLabel iid=new JLabel("Id: ");
		JLabel in=new JLabel("������: ");
		JLabel icity=new JLabel("����: ");
		JLabel icall=new JLabel("����ó: ");
		JLabel iown=new JLabel("������: ");
		
		conf2=new JButton("Configure");
		fiid=new JTextField();
		finame=new JTextField();
		ficity=new JTextField();
		ficall=new JTextField();
		fiown=new JTextField();
		insert.add(iid);
		insert.add(fiid);
		insert.add(in);
		insert.add(finame);
		insert.add(icity);
		insert.add(ficity);
		insert.add(icall);
		insert.add(ficall);
		insert.add(iown);
		insert.add(fiown);
		insert.add(conf2);
		
		JLabel delid=new JLabel("Insert Id: ");
		todel=new JTextField(20);
		del=new JButton("Delete");
		delete.add(delid);
		delete.add(todel);
		delete.add(del);
		
		JLabel sid=new JLabel("Id: ");
		JLabel sin=new JLabel("������: ");
		JLabel scity=new JLabel("����: ");
		JLabel scall=new JLabel("����ó: ");
		JLabel sown=new JLabel("������: ");
		
		fsid=new JTextField();
		fsname=new JTextField();
		fscity=new JTextField();
		fscall=new JTextField();
		fsown=new JTextField();
		conf3=new JButton("Configure");
		search.add(sid);
		search.add(fsid);
		search.add(sin);
		search.add(fsname);
		search.add(scity);
		search.add(fscity);
		search.add(scall);
		search.add(fscall);
		search.add(sown);
		search.add(fsown);
		search.add(conf3);
		insidetab.add("View", view);
		insidetab.add("Update", update);
		insidetab.add("Insert",insert);
		insidetab.add("Delete", delete);
		insidetab.add("Search",search);
		ChangeListener change=new ChangeListener() {
			
			@Override
			public void stateChanged(ChangeEvent e) {
				// TODO Auto-generated method stub
				Vector<String> title=new Vector<>();
				Vector<Vector<String>> data = new Vector<>();
				try {
					data = d.showAllDepts();
				} catch (SQLException e1) {
					// TODO Auto-generated catch block
					e1.printStackTrace();
				}
				title.add("���� Id");
				title.add("������");
				title.add("����");
				title.add("����ó");
				title.add("������ Id");
				DefaultTableModel temp=new DefaultTableModel(title, 0);
				for(int a=0;a<data.size();a++)
				{
					temp.addRow(data.elementAt(a));
				}
				table.setModel(temp);
				
			}
		};
		insidetab.addChangeListener(change);
		add(spane);
		add(insidetab);
		
	}
	public void ShowElement() throws SQLException
	{
		Vector<JTextArea> clist=new Vector<>();
		clist.add(sid);
		clist.add(sname);
		clist.add(scity);
		clist.add(scall);
		clist.add(sown);
		table.addMouseListener(new MouseAdapter() {
			public void mouseClicked(MouseEvent e)
			{
				int row=table.getSelectedRow();
				for(int i=0;i<table.getColumnCount();i++)
				{
					Object a=table.getValueAt(row, i);
					String s=a.toString();
					clist.elementAt(i).setText(s);
					System.out.println(s);
				}
			}
		});
	}
	public void UpdateElement() throws SQLException
	{
		Vector<JTextField> clist=new Vector<>();
		
		conf.addMouseListener(new MouseAdapter() {
			public void mouseClicked(MouseEvent e)
			{
				clist.add(fid);
				clist.add(fname);
				clist.add(fcity);
				clist.add(fcall);
				clist.add(fown);
				Vector<Vector<String>> data=new Vector<>();
				Vector<String> input=new Vector<>();
				for(int i=0;i<table.getColumnCount();i++)
				{
					String s=clist.elementAt(i).getText();
					input.add(s);
				}
				int count=0;
				for(int i=0;i<input.size();i++)
				{
					String a=input.elementAt(i);
					if(a.equals(""))
						count++;
				}
				if(count!=input.size()-1)
				{
				int num=Integer.parseInt(input.elementAt(0));
				try {
					d.updateRow(num, input);
				} catch (SQLException e1) {
					e1.printStackTrace();
				}
				try {
					data = d.showAllDepts();
				} catch (SQLException e1) {
					e1.printStackTrace();
				}
				}
				try {
					data=d.showAllDepts();
				} catch (SQLException e1) {
					// TODO Auto-generated catch block
					e1.printStackTrace();
				}
				Vector<String> title=new Vector<>();
				title.add("���� Id");
				title.add("������");
				title.add("����");
				title.add("����ó");
				title.add("������ Id");
				DefaultTableModel temp=new DefaultTableModel(title, 0);
				for(int a=0;a<data.size();a++)
				{
					temp.addRow(data.elementAt(a));
				}
				table.setModel(temp);
			}
		});
		
	}
	public void InsertRow()	throws SQLException
	{
		Vector<JTextField> clist=new Vector<>();
		
		conf2.addMouseListener(new MouseAdapter() {
			public void mouseClicked(MouseEvent e)
			{
				clist.add(fiid);
				clist.add(finame);
				clist.add(ficity);
				clist.add(ficall);
				clist.add(fiown);
				Vector<Vector<String>> data=new Vector<>();
				Vector<String> input=new Vector<>();
				for(int i=0;i<table.getColumnCount();i++)
				{
					String s=clist.elementAt(i).getText();
					input.add(s);
				}
				int count=0;
				for(int i=0;i<input.size();i++)
				{
					String a=input.elementAt(i);
					if(a.equals(""))
						count++;
				}
				if(count!=input.size()-1)
				{
				int num=Integer.parseInt(input.elementAt(0));
				try {
					d.InsertRow(input);
				} catch (SQLException e1) {
					e1.printStackTrace();
				}
				try {
					data = d.showAllDepts();
				} catch (SQLException e1) {
					e1.printStackTrace();
				}
				}
				try {
					data=d.showAllDepts();
				} catch (SQLException e1) {
					// TODO Auto-generated catch block
					e1.printStackTrace();
				}
				Vector<String> title=new Vector<>();
				title.add("���� Id");
				title.add("������");
				title.add("����");
				title.add("����ó");
				title.add("������ Id");
				DefaultTableModel temp=new DefaultTableModel(title, 0);
				for(int a=0;a<data.size();a++)
				{
					temp.addRow(data.elementAt(a));
				}
				table.setModel(temp);
			}
		});
	}
	public void deleteElement() throws SQLException
	{
		
		del.addMouseListener(new MouseAdapter() {
			public void mouseClicked(MouseEvent e)
			{
				Vector<Vector<String>> data=new Vector<>();
				String s=todel.getText();
				int num=Integer.parseInt(s);
				try {
					d.deleteRow(num);
				} catch (SQLException e1) {
					e1.printStackTrace();
				}
				try {
					data = d.showAllDepts();
				} catch (SQLException e1) {
					e1.printStackTrace();
				}
				try {
					data=d.showAllDepts();
				} catch (SQLException e1) {
					// TODO Auto-generated catch block
					e1.printStackTrace();
				}
				Vector<String> title=new Vector<>();
				title.add("���� Id");
				title.add("������");
				title.add("����");
				title.add("����ó");
				title.add("������ Id");
				DefaultTableModel temp=new DefaultTableModel(title, 0);
				for(int a=0;a<data.size();a++)
				{
					temp.addRow(data.elementAt(a));
				}
				table.setModel(temp);
			}
		});
}
	public void searchItem() throws SQLException
	{
		Vector<JTextField> clist=new Vector<>();
		conf3.addMouseListener(new MouseAdapter() {
			public void mouseClicked(MouseEvent e)
			{
				clist.add(fsid);
				clist.add(fsname);
				clist.add(fscity);
				clist.add(fscall);
				clist.add(fsown);
				Vector<Vector<String>> data=new Vector<>();
				Vector<String> input=new Vector<>();
				for(int i=0;i<table.getColumnCount();i++)
				{
					String s=clist.elementAt(i).getText();
					input.add(s);
				}
				try {
					data = d.searchWithManyKeywords(input);
				} catch (SQLException e1) {
					e1.printStackTrace();
				}
				try {
					data = d.searchWithManyKeywords(input);
				} catch (SQLException e1) {
					// TODO Auto-generated catch block
					e1.printStackTrace();
				}
				Vector<String> title=new Vector<>();
				title.add("���� Id");
				title.add("������");
				title.add("����");
				title.add("����ó");
				title.add("������ Id");
				DefaultTableModel temp=new DefaultTableModel(title, 0);
				for(int a=0;a<data.size();a++)
				{
					temp.addRow(data.elementAt(a));
				}
				table.setModel(temp);
			}
		});
	}
}
class ClientPanel extends JPanel
{/**
	 * 
	 */
	private static final long serialVersionUID = 1L;
	private DeptHandler d;
	private JScrollPane spane;
	private JPanel view;
	private JPanel insert;
	private JPanel update;
	private JPanel delete;
	private JPanel search;
	private JTabbedPane insidetab;
	private JTable table;
	private JLabel id;
	private JLabel name;
	private JLabel city;
	private JLabel call;
	private JLabel own;
	private JTextArea sid;
	private JTextArea sname;
	private JTextArea scall;
	private JTextArea sown;
	private JTextArea scity;
	private JTextField fid;
	private JTextField fname;
	private JTextField fcall;
	private JTextField fown;
	private JTextField fcity;	
	private JTextField fiid;
	private JTextField finame;
	private JTextField ficall;
	private JTextField fiown;
	private JTextField ficity;
	private JTextField todel;
	private JButton conf;
	private JButton conf2;
	private JButton del;
	private JTextField fsid;
	private JTextField fsname;
	private JTextField fscall;
	private JTextField fsown;
	private JTextField fscity;
	private JButton conf3;
	public ClientPanel() throws SQLException
	{
		insidetab=new JTabbedPane();
		d=new DeptHandler();
		Vector<Vector<String>> data=d.showAllDepts();
		Vector<String> title=new Vector<>();
		title.add("���� Id");
		title.add("������");
		title.add("����");
		title.add("����ó");
		title.add("������ Id");
		DefaultTableModel model=new DefaultTableModel(title,0);
		for(int i=0;i<data.size();i++)
		{
			model.addRow(data.elementAt(i));
		}
		table=new JTable(model);
		spane=new JScrollPane(table);
		setLayout(new GridLayout(1,2));
		view=new JPanel();
		update=new JPanel();
		insert=new JPanel();
		delete=new JPanel();
		search=new JPanel();
		view.setLayout(new BoxLayout(view, BoxLayout.Y_AXIS));
		update.setLayout(new BoxLayout(update, BoxLayout.Y_AXIS));
		insert.setLayout(new BoxLayout(insert, BoxLayout.Y_AXIS));
		search.setLayout(new BoxLayout(search, BoxLayout.Y_AXIS));
		delete.setLayout(new FlowLayout());
		
		id=new JLabel("Id: ");
		name=new JLabel("������: ");
		city=new JLabel("����: ");
		call=new JLabel("����ó: ");
		own=new JLabel("������: ");
		
		sid=new JTextArea();
		sname=new JTextArea();
		scity=new JTextArea();
		scall=new JTextArea();
		sown=new JTextArea();
		
		view.add(id);
		view.add(sid);
		view.add(name);
		view.add(sname);
		view.add(city);
		view.add(scity);
		view.add(call);
		view.add(scall);
		view.add(own);
		view.add(sown);

		
		fid=new JTextField();
		fname=new JTextField();
		fcity=new JTextField();
		fcall=new JTextField();
		fown=new JTextField();
		
		JLabel uid=new JLabel("Id: ");
		JLabel un=new JLabel("������: ");
		JLabel ucity=new JLabel("����: ");
		JLabel ucall=new JLabel("����ó: ");
		JLabel uown=new JLabel("������: ");
		
		conf=new JButton("Configure");
		update.add(uid);
		update.add(fid);
		update.add(un);
		update.add(fname);
		update.add(ucity);
		update.add(fcity);
		update.add(ucall);
		update.add(fcall);
		update.add(uown);
		update.add(fown);
		update.add(conf);
		
		JLabel iid=new JLabel("Id: ");
		JLabel in=new JLabel("������: ");
		JLabel icity=new JLabel("����: ");
		JLabel icall=new JLabel("����ó: ");
		JLabel iown=new JLabel("������: ");
		
		conf2=new JButton("Configure");
		fiid=new JTextField();
		finame=new JTextField();
		ficity=new JTextField();
		ficall=new JTextField();
		fiown=new JTextField();
		insert.add(iid);
		insert.add(fiid);
		insert.add(in);
		insert.add(finame);
		insert.add(icity);
		insert.add(ficity);
		insert.add(icall);
		insert.add(ficall);
		insert.add(iown);
		insert.add(fiown);
		insert.add(conf2);
		
		JLabel delid=new JLabel("Insert Id: ");
		todel=new JTextField(20);
		del=new JButton("Delete");
		delete.add(delid);
		delete.add(todel);
		delete.add(del);
		
		JLabel sid=new JLabel("Id: ");
		JLabel sin=new JLabel("������: ");
		JLabel scity=new JLabel("����: ");
		JLabel scall=new JLabel("����ó: ");
		JLabel sown=new JLabel("������: ");
		
		fsid=new JTextField();
		fsname=new JTextField();
		fscity=new JTextField();
		fscall=new JTextField();
		fsown=new JTextField();
		conf3=new JButton("Configure");
		search.add(sid);
		search.add(fsid);
		search.add(sin);
		search.add(fsname);
		search.add(scity);
		search.add(fscity);
		search.add(scall);
		search.add(fscall);
		search.add(sown);
		search.add(fsown);
		search.add(conf3);
		insidetab.add("View", view);
		insidetab.add("Update", update);
		insidetab.add("Insert",insert);
		insidetab.add("Delete", delete);
		insidetab.add("Search",search);
		ChangeListener change=new ChangeListener() {
			
			@Override
			public void stateChanged(ChangeEvent e) {
				// TODO Auto-generated method stub
				Vector<String> title=new Vector<>();
				Vector<Vector<String>> data = new Vector<>();
				try {
					data = d.showAllDepts();
				} catch (SQLException e1) {
					// TODO Auto-generated catch block
					e1.printStackTrace();
				}
				title.add("���� Id");
				title.add("������");
				title.add("����");
				title.add("����ó");
				title.add("������ Id");
				DefaultTableModel temp=new DefaultTableModel(title, 0);
				for(int a=0;a<data.size();a++)
				{
					temp.addRow(data.elementAt(a));
				}
				table.setModel(temp);
				
			}
		};
		insidetab.addChangeListener(change);
		add(spane);
		add(insidetab);
		
	}
	public void ShowElement() throws SQLException
	{
		Vector<JTextArea> clist=new Vector<>();
		clist.add(sid);
		clist.add(sname);
		clist.add(scity);
		clist.add(scall);
		clist.add(sown);
		table.addMouseListener(new MouseAdapter() {
			public void mouseClicked(MouseEvent e)
			{
				int row=table.getSelectedRow();
				for(int i=0;i<table.getColumnCount();i++)
				{
					Object a=table.getValueAt(row, i);
					String s=a.toString();
					clist.elementAt(i).setText(s);
					System.out.println(s);
				}
			}
		});
	}
	public void UpdateElement() throws SQLException
	{
		Vector<JTextField> clist=new Vector<>();
		
		conf.addMouseListener(new MouseAdapter() {
			public void mouseClicked(MouseEvent e)
			{
				clist.add(fid);
				clist.add(fname);
				clist.add(fcity);
				clist.add(fcall);
				clist.add(fown);
				Vector<Vector<String>> data=new Vector<>();
				Vector<String> input=new Vector<>();
				for(int i=0;i<table.getColumnCount();i++)
				{
					String s=clist.elementAt(i).getText();
					input.add(s);
				}
				int count=0;
				for(int i=0;i<input.size();i++)
				{
					String a=input.elementAt(i);
					if(a.equals(""))
						count++;
				}
				if(count!=input.size()-1)
				{
				int num=Integer.parseInt(input.elementAt(0));
				try {
					d.updateRow(num, input);
				} catch (SQLException e1) {
					e1.printStackTrace();
				}
				try {
					data = d.showAllDepts();
				} catch (SQLException e1) {
					e1.printStackTrace();
				}
				}
				try {
					data=d.showAllDepts();
				} catch (SQLException e1) {
					// TODO Auto-generated catch block
					e1.printStackTrace();
				}
				Vector<String> title=new Vector<>();
				title.add("���� Id");
				title.add("������");
				title.add("����");
				title.add("����ó");
				title.add("������ Id");
				DefaultTableModel temp=new DefaultTableModel(title, 0);
				for(int a=0;a<data.size();a++)
				{
					temp.addRow(data.elementAt(a));
				}
				table.setModel(temp);
			}
		});
		
	}
	public void InsertRow()	throws SQLException
	{
		Vector<JTextField> clist=new Vector<>();
		
		conf2.addMouseListener(new MouseAdapter() {
			public void mouseClicked(MouseEvent e)
			{
				clist.add(fiid);
				clist.add(finame);
				clist.add(ficity);
				clist.add(ficall);
				clist.add(fiown);
				Vector<Vector<String>> data=new Vector<>();
				Vector<String> input=new Vector<>();
				for(int i=0;i<table.getColumnCount();i++)
				{
					String s=clist.elementAt(i).getText();
					input.add(s);
				}
				int count=0;
				for(int i=0;i<input.size();i++)
				{
					String a=input.elementAt(i);
					if(a.equals(""))
						count++;
				}
				if(count!=input.size()-1)
				{
				int num=Integer.parseInt(input.elementAt(0));
				try {
					d.InsertRow(input);
				} catch (SQLException e1) {
					e1.printStackTrace();
				}
				try {
					data = d.showAllDepts();
				} catch (SQLException e1) {
					e1.printStackTrace();
				}
				}
				try {
					data=d.showAllDepts();
				} catch (SQLException e1) {
					// TODO Auto-generated catch block
					e1.printStackTrace();
				}
				Vector<String> title=new Vector<>();
				title.add("���� Id");
				title.add("������");
				title.add("����");
				title.add("����ó");
				title.add("������ Id");
				DefaultTableModel temp=new DefaultTableModel(title, 0);
				for(int a=0;a<data.size();a++)
				{
					temp.addRow(data.elementAt(a));
				}
				table.setModel(temp);
			}
		});
	}
	public void deleteElement() throws SQLException
	{
		
		del.addMouseListener(new MouseAdapter() {
			public void mouseClicked(MouseEvent e)
			{
				Vector<Vector<String>> data=new Vector<>();
				String s=todel.getText();
				int num=Integer.parseInt(s);
				try {
					d.deleteRow(num);
				} catch (SQLException e1) {
					e1.printStackTrace();
				}
				try {
					data = d.showAllDepts();
				} catch (SQLException e1) {
					e1.printStackTrace();
				}
				try {
					data=d.showAllDepts();
				} catch (SQLException e1) {
					// TODO Auto-generated catch block
					e1.printStackTrace();
				}
				Vector<String> title=new Vector<>();
				title.add("���� Id");
				title.add("������");
				title.add("����");
				title.add("����ó");
				title.add("������ Id");
				DefaultTableModel temp=new DefaultTableModel(title, 0);
				for(int a=0;a<data.size();a++)
				{
					temp.addRow(data.elementAt(a));
				}
				table.setModel(temp);
			}
		});
}
	public void searchItem() throws SQLException
	{
		Vector<JTextField> clist=new Vector<>();
		conf3.addMouseListener(new MouseAdapter() {
			public void mouseClicked(MouseEvent e)
			{
				clist.add(fsid);
				clist.add(fsname);
				clist.add(fscity);
				clist.add(fscall);
				clist.add(fsown);
				Vector<Vector<String>> data=new Vector<>();
				Vector<String> input=new Vector<>();
				for(int i=0;i<table.getColumnCount();i++)
				{
					String s=clist.elementAt(i).getText();
					input.add(s);
				}
				try {
					data = d.searchWithManyKeywords(input);
				} catch (SQLException e1) {
					e1.printStackTrace();
				}
				try {
					data = d.searchWithManyKeywords(input);
				} catch (SQLException e1) {
					// TODO Auto-generated catch block
					e1.printStackTrace();
				}
				Vector<String> title=new Vector<>();
				title.add("���� Id");
				title.add("������");
				title.add("����");
				title.add("����ó");
				title.add("������ Id");
				DefaultTableModel temp=new DefaultTableModel(title, 0);
				for(int a=0;a<data.size();a++)
				{
					temp.addRow(data.elementAt(a));
				}
				table.setModel(temp);
			}
		});
	}
}

class EmployeePanel extends JPanel
{/**
	 * 
	 */
	private static final long serialVersionUID = 1L;
	private DeptHandler d;
	private JScrollPane spane;
	private JPanel view;
	private JPanel insert;
	private JPanel update;
	private JPanel delete;
	private JPanel search;
	private JTabbedPane insidetab;
	private JTable table;
	private JLabel id;
	private JLabel name;
	private JLabel city;
	private JLabel call;
	private JLabel own;
	private JTextArea sid;
	private JTextArea sname;
	private JTextArea scall;
	private JTextArea sown;
	private JTextArea scity;
	private JTextField fid;
	private JTextField fname;
	private JTextField fcall;
	private JTextField fown;
	private JTextField fcity;	
	private JTextField fiid;
	private JTextField finame;
	private JTextField ficall;
	private JTextField fiown;
	private JTextField ficity;
	private JTextField todel;
	private JButton conf;
	private JButton conf2;
	private JButton del;
	private JTextField fsid;
	private JTextField fsname;
	private JTextField fscall;
	private JTextField fsown;
	private JTextField fscity;
	private JButton conf3;
	public EmployeePanel() throws SQLException
	{
		insidetab=new JTabbedPane();
		d=new DeptHandler();
		Vector<Vector<String>> data=d.showAllDepts();
		Vector<String> title=new Vector<>();
		title.add("���� Id");
		title.add("������");
		title.add("����");
		title.add("����ó");
		title.add("������ Id");
		DefaultTableModel model=new DefaultTableModel(title,0);
		for(int i=0;i<data.size();i++)
		{
			model.addRow(data.elementAt(i));
		}
		table=new JTable(model);
		spane=new JScrollPane(table);
		setLayout(new GridLayout(1,2));
		view=new JPanel();
		update=new JPanel();
		insert=new JPanel();
		delete=new JPanel();
		search=new JPanel();
		view.setLayout(new BoxLayout(view, BoxLayout.Y_AXIS));
		update.setLayout(new BoxLayout(update, BoxLayout.Y_AXIS));
		insert.setLayout(new BoxLayout(insert, BoxLayout.Y_AXIS));
		search.setLayout(new BoxLayout(search, BoxLayout.Y_AXIS));
		delete.setLayout(new FlowLayout());
		
		id=new JLabel("Id: ");
		name=new JLabel("������: ");
		city=new JLabel("����: ");
		call=new JLabel("����ó: ");
		own=new JLabel("������: ");
		
		sid=new JTextArea();
		sname=new JTextArea();
		scity=new JTextArea();
		scall=new JTextArea();
		sown=new JTextArea();
		
		view.add(id);
		view.add(sid);
		view.add(name);
		view.add(sname);
		view.add(city);
		view.add(scity);
		view.add(call);
		view.add(scall);
		view.add(own);
		view.add(sown);

		
		fid=new JTextField();
		fname=new JTextField();
		fcity=new JTextField();
		fcall=new JTextField();
		fown=new JTextField();
		
		JLabel uid=new JLabel("Id: ");
		JLabel un=new JLabel("������: ");
		JLabel ucity=new JLabel("����: ");
		JLabel ucall=new JLabel("����ó: ");
		JLabel uown=new JLabel("������: ");
		
		conf=new JButton("Configure");
		update.add(uid);
		update.add(fid);
		update.add(un);
		update.add(fname);
		update.add(ucity);
		update.add(fcity);
		update.add(ucall);
		update.add(fcall);
		update.add(uown);
		update.add(fown);
		update.add(conf);
		
		JLabel iid=new JLabel("Id: ");
		JLabel in=new JLabel("������: ");
		JLabel icity=new JLabel("����: ");
		JLabel icall=new JLabel("����ó: ");
		JLabel iown=new JLabel("������: ");
		
		conf2=new JButton("Configure");
		fiid=new JTextField();
		finame=new JTextField();
		ficity=new JTextField();
		ficall=new JTextField();
		fiown=new JTextField();
		insert.add(iid);
		insert.add(fiid);
		insert.add(in);
		insert.add(finame);
		insert.add(icity);
		insert.add(ficity);
		insert.add(icall);
		insert.add(ficall);
		insert.add(iown);
		insert.add(fiown);
		insert.add(conf2);
		
		JLabel delid=new JLabel("Insert Id: ");
		todel=new JTextField(20);
		del=new JButton("Delete");
		delete.add(delid);
		delete.add(todel);
		delete.add(del);
		
		JLabel sid=new JLabel("Id: ");
		JLabel sin=new JLabel("������: ");
		JLabel scity=new JLabel("����: ");
		JLabel scall=new JLabel("����ó: ");
		JLabel sown=new JLabel("������: ");
		
		fsid=new JTextField();
		fsname=new JTextField();
		fscity=new JTextField();
		fscall=new JTextField();
		fsown=new JTextField();
		conf3=new JButton("Configure");
		search.add(sid);
		search.add(fsid);
		search.add(sin);
		search.add(fsname);
		search.add(scity);
		search.add(fscity);
		search.add(scall);
		search.add(fscall);
		search.add(sown);
		search.add(fsown);
		search.add(conf3);
		insidetab.add("View", view);
		insidetab.add("Update", update);
		insidetab.add("Insert",insert);
		insidetab.add("Delete", delete);
		insidetab.add("Search",search);
		ChangeListener change=new ChangeListener() {
			
			@Override
			public void stateChanged(ChangeEvent e) {
				// TODO Auto-generated method stub
				Vector<String> title=new Vector<>();
				Vector<Vector<String>> data = new Vector<>();
				try {
					data = d.showAllDepts();
				} catch (SQLException e1) {
					// TODO Auto-generated catch block
					e1.printStackTrace();
				}
				title.add("���� Id");
				title.add("������");
				title.add("����");
				title.add("����ó");
				title.add("������ Id");
				DefaultTableModel temp=new DefaultTableModel(title, 0);
				for(int a=0;a<data.size();a++)
				{
					temp.addRow(data.elementAt(a));
				}
				table.setModel(temp);
				
			}
		};
		insidetab.addChangeListener(change);
		add(spane);
		add(insidetab);
		
	}
	public void ShowElement() throws SQLException
	{
		Vector<JTextArea> clist=new Vector<>();
		clist.add(sid);
		clist.add(sname);
		clist.add(scity);
		clist.add(scall);
		clist.add(sown);
		table.addMouseListener(new MouseAdapter() {
			public void mouseClicked(MouseEvent e)
			{
				int row=table.getSelectedRow();
				for(int i=0;i<table.getColumnCount();i++)
				{
					Object a=table.getValueAt(row, i);
					String s=a.toString();
					clist.elementAt(i).setText(s);
					System.out.println(s);
				}
			}
		});
	}
	public void UpdateElement() throws SQLException
	{
		Vector<JTextField> clist=new Vector<>();
		
		conf.addMouseListener(new MouseAdapter() {
			public void mouseClicked(MouseEvent e)
			{
				clist.add(fid);
				clist.add(fname);
				clist.add(fcity);
				clist.add(fcall);
				clist.add(fown);
				Vector<Vector<String>> data=new Vector<>();
				Vector<String> input=new Vector<>();
				for(int i=0;i<table.getColumnCount();i++)
				{
					String s=clist.elementAt(i).getText();
					input.add(s);
				}
				int count=0;
				for(int i=0;i<input.size();i++)
				{
					String a=input.elementAt(i);
					if(a.equals(""))
						count++;
				}
				if(count!=input.size()-1)
				{
				int num=Integer.parseInt(input.elementAt(0));
				try {
					d.updateRow(num, input);
				} catch (SQLException e1) {
					e1.printStackTrace();
				}
				try {
					data = d.showAllDepts();
				} catch (SQLException e1) {
					e1.printStackTrace();
				}
				}
				try {
					data=d.showAllDepts();
				} catch (SQLException e1) {
					// TODO Auto-generated catch block
					e1.printStackTrace();
				}
				Vector<String> title=new Vector<>();
				title.add("���� Id");
				title.add("������");
				title.add("����");
				title.add("����ó");
				title.add("������ Id");
				DefaultTableModel temp=new DefaultTableModel(title, 0);
				for(int a=0;a<data.size();a++)
				{
					temp.addRow(data.elementAt(a));
				}
				table.setModel(temp);
			}
		});
		
	}
	public void InsertRow()	throws SQLException
	{
		Vector<JTextField> clist=new Vector<>();
		
		conf2.addMouseListener(new MouseAdapter() {
			public void mouseClicked(MouseEvent e)
			{
				clist.add(fiid);
				clist.add(finame);
				clist.add(ficity);
				clist.add(ficall);
				clist.add(fiown);
				Vector<Vector<String>> data=new Vector<>();
				Vector<String> input=new Vector<>();
				for(int i=0;i<table.getColumnCount();i++)
				{
					String s=clist.elementAt(i).getText();
					input.add(s);
				}
				int count=0;
				for(int i=0;i<input.size();i++)
				{
					String a=input.elementAt(i);
					if(a.equals(""))
						count++;
				}
				if(count!=input.size()-1)
				{
				int num=Integer.parseInt(input.elementAt(0));
				try {
					d.InsertRow(input);
				} catch (SQLException e1) {
					e1.printStackTrace();
				}
				try {
					data = d.showAllDepts();
				} catch (SQLException e1) {
					e1.printStackTrace();
				}
				}
				try {
					data=d.showAllDepts();
				} catch (SQLException e1) {
					// TODO Auto-generated catch block
					e1.printStackTrace();
				}
				Vector<String> title=new Vector<>();
				title.add("���� Id");
				title.add("������");
				title.add("����");
				title.add("����ó");
				title.add("������ Id");
				DefaultTableModel temp=new DefaultTableModel(title, 0);
				for(int a=0;a<data.size();a++)
				{
					temp.addRow(data.elementAt(a));
				}
				table.setModel(temp);
			}
		});
	}
	public void deleteElement() throws SQLException
	{
		
		del.addMouseListener(new MouseAdapter() {
			public void mouseClicked(MouseEvent e)
			{
				Vector<Vector<String>> data=new Vector<>();
				String s=todel.getText();
				int num=Integer.parseInt(s);
				try {
					d.deleteRow(num);
				} catch (SQLException e1) {
					e1.printStackTrace();
				}
				try {
					data = d.showAllDepts();
				} catch (SQLException e1) {
					e1.printStackTrace();
				}
				try {
					data=d.showAllDepts();
				} catch (SQLException e1) {
					// TODO Auto-generated catch block
					e1.printStackTrace();
				}
				Vector<String> title=new Vector<>();
				title.add("���� Id");
				title.add("������");
				title.add("����");
				title.add("����ó");
				title.add("������ Id");
				DefaultTableModel temp=new DefaultTableModel(title, 0);
				for(int a=0;a<data.size();a++)
				{
					temp.addRow(data.elementAt(a));
				}
				table.setModel(temp);
			}
		});
}
	public void searchItem() throws SQLException
	{
		Vector<JTextField> clist=new Vector<>();
		conf3.addMouseListener(new MouseAdapter() {
			public void mouseClicked(MouseEvent e)
			{
				clist.add(fsid);
				clist.add(fsname);
				clist.add(fscity);
				clist.add(fscall);
				clist.add(fsown);
				Vector<Vector<String>> data=new Vector<>();
				Vector<String> input=new Vector<>();
				for(int i=0;i<table.getColumnCount();i++)
				{
					String s=clist.elementAt(i).getText();
					input.add(s);
				}
				try {
					data = d.searchWithManyKeywords(input);
				} catch (SQLException e1) {
					e1.printStackTrace();
				}
				try {
					data = d.searchWithManyKeywords(input);
				} catch (SQLException e1) {
					// TODO Auto-generated catch block
					e1.printStackTrace();
				}
				Vector<String> title=new Vector<>();
				title.add("���� Id");
				title.add("������");
				title.add("����");
				title.add("����ó");
				title.add("������ Id");
				DefaultTableModel temp=new DefaultTableModel(title, 0);
				for(int a=0;a<data.size();a++)
				{
					temp.addRow(data.elementAt(a));
				}
				table.setModel(temp);
			}
		});
	}
}
class ItemPanel extends JPanel
{
	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;
	private DeptHandler d;
	private JScrollPane spane;
	private JPanel view;
	private JPanel insert;
	private JPanel update;
	private JPanel delete;
	private JPanel search;
	private JTabbedPane insidetab;
	private JTable table;
	private JLabel id;
	private JLabel name;
	private JLabel city;
	private JLabel call;
	private JLabel own;
	private JTextArea sid;
	private JTextArea sname;
	private JTextArea scall;
	private JTextArea sown;
	private JTextArea scity;
	private JTextField fid;
	private JTextField fname;
	private JTextField fcall;
	private JTextField fown;
	private JTextField fcity;	
	private JTextField fiid;
	private JTextField finame;
	private JTextField ficall;
	private JTextField fiown;
	private JTextField ficity;
	private JTextField todel;
	private JButton conf;
	private JButton conf2;
	private JButton del;
	private JTextField fsid;
	private JTextField fsname;
	private JTextField fscall;
	private JTextField fsown;
	private JTextField fscity;
	private JButton conf3;
	public ItemPanel() throws SQLException
	{
		insidetab=new JTabbedPane();
		d=new DeptHandler();
		Vector<Vector<String>> data=d.showAllDepts();
		Vector<String> title=new Vector<>();
		title.add("���� Id");
		title.add("������");
		title.add("����");
		title.add("����ó");
		title.add("������ Id");
		DefaultTableModel model=new DefaultTableModel(title,0);
		for(int i=0;i<data.size();i++)
		{
			model.addRow(data.elementAt(i));
		}
		table=new JTable(model);
		spane=new JScrollPane(table);
		setLayout(new GridLayout(1,2));
		view=new JPanel();
		update=new JPanel();
		insert=new JPanel();
		delete=new JPanel();
		search=new JPanel();
		view.setLayout(new BoxLayout(view, BoxLayout.Y_AXIS));
		update.setLayout(new BoxLayout(update, BoxLayout.Y_AXIS));
		insert.setLayout(new BoxLayout(insert, BoxLayout.Y_AXIS));
		search.setLayout(new BoxLayout(search, BoxLayout.Y_AXIS));
		delete.setLayout(new FlowLayout());
		
		id=new JLabel("Id: ");
		name=new JLabel("������: ");
		city=new JLabel("����: ");
		call=new JLabel("����ó: ");
		own=new JLabel("������: ");
		
		sid=new JTextArea();
		sname=new JTextArea();
		scity=new JTextArea();
		scall=new JTextArea();
		sown=new JTextArea();
		
		view.add(id);
		view.add(sid);
		view.add(name);
		view.add(sname);
		view.add(city);
		view.add(scity);
		view.add(call);
		view.add(scall);
		view.add(own);
		view.add(sown);

		
		fid=new JTextField();
		fname=new JTextField();
		fcity=new JTextField();
		fcall=new JTextField();
		fown=new JTextField();
		
		JLabel uid=new JLabel("Id: ");
		JLabel un=new JLabel("������: ");
		JLabel ucity=new JLabel("����: ");
		JLabel ucall=new JLabel("����ó: ");
		JLabel uown=new JLabel("������: ");
		
		conf=new JButton("Configure");
		update.add(uid);
		update.add(fid);
		update.add(un);
		update.add(fname);
		update.add(ucity);
		update.add(fcity);
		update.add(ucall);
		update.add(fcall);
		update.add(uown);
		update.add(fown);
		update.add(conf);
		
		JLabel iid=new JLabel("Id: ");
		JLabel in=new JLabel("������: ");
		JLabel icity=new JLabel("����: ");
		JLabel icall=new JLabel("����ó: ");
		JLabel iown=new JLabel("������: ");
		
		conf2=new JButton("Configure");
		fiid=new JTextField();
		finame=new JTextField();
		ficity=new JTextField();
		ficall=new JTextField();
		fiown=new JTextField();
		insert.add(iid);
		insert.add(fiid);
		insert.add(in);
		insert.add(finame);
		insert.add(icity);
		insert.add(ficity);
		insert.add(icall);
		insert.add(ficall);
		insert.add(iown);
		insert.add(fiown);
		insert.add(conf2);
		
		JLabel delid=new JLabel("Insert Id: ");
		todel=new JTextField(20);
		del=new JButton("Delete");
		delete.add(delid);
		delete.add(todel);
		delete.add(del);
		
		JLabel sid=new JLabel("Id: ");
		JLabel sin=new JLabel("������: ");
		JLabel scity=new JLabel("����: ");
		JLabel scall=new JLabel("����ó: ");
		JLabel sown=new JLabel("������: ");
		
		fsid=new JTextField();
		fsname=new JTextField();
		fscity=new JTextField();
		fscall=new JTextField();
		fsown=new JTextField();
		conf3=new JButton("Configure");
		search.add(sid);
		search.add(fsid);
		search.add(sin);
		search.add(fsname);
		search.add(scity);
		search.add(fscity);
		search.add(scall);
		search.add(fscall);
		search.add(sown);
		search.add(fsown);
		search.add(conf3);
		insidetab.add("View", view);
		insidetab.add("Update", update);
		insidetab.add("Insert",insert);
		insidetab.add("Delete", delete);
		insidetab.add("Search",search);
		ChangeListener change=new ChangeListener() {
			
			@Override
			public void stateChanged(ChangeEvent e) {
				// TODO Auto-generated method stub
				Vector<String> title=new Vector<>();
				Vector<Vector<String>> data = new Vector<>();
				try {
					data = d.showAllDepts();
				} catch (SQLException e1) {
					// TODO Auto-generated catch block
					e1.printStackTrace();
				}
				title.add("���� Id");
				title.add("������");
				title.add("����");
				title.add("����ó");
				title.add("������ Id");
				DefaultTableModel temp=new DefaultTableModel(title, 0);
				for(int a=0;a<data.size();a++)
				{
					temp.addRow(data.elementAt(a));
				}
				table.setModel(temp);
				
			}
		};
		insidetab.addChangeListener(change);
		add(spane);
		add(insidetab);
		
	}
	public void ShowElement() throws SQLException
	{
		Vector<JTextArea> clist=new Vector<>();
		clist.add(sid);
		clist.add(sname);
		clist.add(scity);
		clist.add(scall);
		clist.add(sown);
		table.addMouseListener(new MouseAdapter() {
			public void mouseClicked(MouseEvent e)
			{
				int row=table.getSelectedRow();
				for(int i=0;i<table.getColumnCount();i++)
				{
					Object a=table.getValueAt(row, i);
					String s=a.toString();
					clist.elementAt(i).setText(s);
					System.out.println(s);
				}
			}
		});
	}
	public void UpdateElement() throws SQLException
	{
		Vector<JTextField> clist=new Vector<>();
		
		conf.addMouseListener(new MouseAdapter() {
			public void mouseClicked(MouseEvent e)
			{
				clist.add(fid);
				clist.add(fname);
				clist.add(fcity);
				clist.add(fcall);
				clist.add(fown);
				Vector<Vector<String>> data=new Vector<>();
				Vector<String> input=new Vector<>();
				for(int i=0;i<table.getColumnCount();i++)
				{
					String s=clist.elementAt(i).getText();
					input.add(s);
				}
				int count=0;
				for(int i=0;i<input.size();i++)
				{
					String a=input.elementAt(i);
					if(a.equals(""))
						count++;
				}
				if(count!=input.size()-1)
				{
				int num=Integer.parseInt(input.elementAt(0));
				try {
					d.updateRow(num, input);
				} catch (SQLException e1) {
					e1.printStackTrace();
				}
				try {
					data = d.showAllDepts();
				} catch (SQLException e1) {
					e1.printStackTrace();
				}
				}
				try {
					data=d.showAllDepts();
				} catch (SQLException e1) {
					// TODO Auto-generated catch block
					e1.printStackTrace();
				}
				Vector<String> title=new Vector<>();
				title.add("���� Id");
				title.add("������");
				title.add("����");
				title.add("����ó");
				title.add("������ Id");
				DefaultTableModel temp=new DefaultTableModel(title, 0);
				for(int a=0;a<data.size();a++)
				{
					temp.addRow(data.elementAt(a));
				}
				table.setModel(temp);
			}
		});
		
	}
	public void InsertRow()	throws SQLException
	{
		Vector<JTextField> clist=new Vector<>();
		
		conf2.addMouseListener(new MouseAdapter() {
			public void mouseClicked(MouseEvent e)
			{
				clist.add(fiid);
				clist.add(finame);
				clist.add(ficity);
				clist.add(ficall);
				clist.add(fiown);
				Vector<Vector<String>> data=new Vector<>();
				Vector<String> input=new Vector<>();
				for(int i=0;i<table.getColumnCount();i++)
				{
					String s=clist.elementAt(i).getText();
					input.add(s);
				}
				int count=0;
				for(int i=0;i<input.size();i++)
				{
					String a=input.elementAt(i);
					if(a.equals(""))
						count++;
				}
				if(count!=input.size()-1)
				{
				int num=Integer.parseInt(input.elementAt(0));
				try {
					d.InsertRow(input);
				} catch (SQLException e1) {
					e1.printStackTrace();
				}
				try {
					data = d.showAllDepts();
				} catch (SQLException e1) {
					e1.printStackTrace();
				}
				}
				try {
					data=d.showAllDepts();
				} catch (SQLException e1) {
					// TODO Auto-generated catch block
					e1.printStackTrace();
				}
				Vector<String> title=new Vector<>();
				title.add("���� Id");
				title.add("������");
				title.add("����");
				title.add("����ó");
				title.add("������ Id");
				DefaultTableModel temp=new DefaultTableModel(title, 0);
				for(int a=0;a<data.size();a++)
				{
					temp.addRow(data.elementAt(a));
				}
				table.setModel(temp);
			}
		});
	}
	public void deleteElement() throws SQLException
	{
		
		del.addMouseListener(new MouseAdapter() {
			public void mouseClicked(MouseEvent e)
			{
				Vector<Vector<String>> data=new Vector<>();
				String s=todel.getText();
				int num=Integer.parseInt(s);
				try {
					d.deleteRow(num);
				} catch (SQLException e1) {
					e1.printStackTrace();
				}
				try {
					data = d.showAllDepts();
				} catch (SQLException e1) {
					e1.printStackTrace();
				}
				try {
					data=d.showAllDepts();
				} catch (SQLException e1) {
					// TODO Auto-generated catch block
					e1.printStackTrace();
				}
				Vector<String> title=new Vector<>();
				title.add("���� Id");
				title.add("������");
				title.add("����");
				title.add("����ó");
				title.add("������ Id");
				DefaultTableModel temp=new DefaultTableModel(title, 0);
				for(int a=0;a<data.size();a++)
				{
					temp.addRow(data.elementAt(a));
				}
				table.setModel(temp);
			}
		});
}
	public void searchItem() throws SQLException
	{
		Vector<JTextField> clist=new Vector<>();
		conf3.addMouseListener(new MouseAdapter() {
			public void mouseClicked(MouseEvent e)
			{
				clist.add(fsid);
				clist.add(fsname);
				clist.add(fscity);
				clist.add(fscall);
				clist.add(fsown);
				Vector<Vector<String>> data=new Vector<>();
				Vector<String> input=new Vector<>();
				for(int i=0;i<table.getColumnCount();i++)
				{
					String s=clist.elementAt(i).getText();
					input.add(s);
				}
				try {
					data = d.searchWithManyKeywords(input);
				} catch (SQLException e1) {
					e1.printStackTrace();
				}
				try {
					data = d.searchWithManyKeywords(input);
				} catch (SQLException e1) {
					// TODO Auto-generated catch block
					e1.printStackTrace();
				}
				Vector<String> title=new Vector<>();
				title.add("���� Id");
				title.add("������");
				title.add("����");
				title.add("����ó");
				title.add("������ Id");
				DefaultTableModel temp=new DefaultTableModel(title, 0);
				for(int a=0;a<data.size();a++)
				{
					temp.addRow(data.elementAt(a));
				}
				table.setModel(temp);
			}
		});
	}

}
public class DBEditDialog extends JDialog{
	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;
	private DeptPanel dept;
	private StorePanel store;
	private ItemPanel item;
	private EmployeePanel emp;
	private ClientPanel client;
JTextField tf=new JTextField(10);
JButton okButton=new JButton("OK");
	public DBEditDialog(JFrame frame) throws SQLException
	{
		super(frame);
		setTitle("Database Edit Menu");
		dept=new DeptPanel();
		store=new StorePanel();
		item=new ItemPanel();
		emp=new EmployeePanel();
		client=new ClientPanel();
		JTabbedPane jtab=new JTabbedPane();
		jtab.add("dept", dept);
		jtab.add("store", store);
		jtab.add("employee",emp);
		jtab.add("client",client);
		jtab.add("items", item);
		add(jtab);
		dept.ShowElement();
		dept.UpdateElement();
		dept.InsertRow();
		dept.deleteElement();
		dept.searchItem();
		store.ShowElement();
		store.UpdateElement();
		store.InsertRow();
		store.deleteElement();
		setDefaultCloseOperation(JFrame.DISPOSE_ON_CLOSE);
		//add(tf);
		//add(okButton);
		//setLayout(new FlowLayout());
		//frame.add(pane);
		setSize(700, 500);
		okButton.addActionListener(new ActionListener() {
			
			@Override
			public void actionPerformed(ActionEvent e) {
				
				setVisible(false);
			}
		});
	}
}
