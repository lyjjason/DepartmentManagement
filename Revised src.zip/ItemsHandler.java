import java.sql.*;
import java.util.Vector;
public class ItemsHandler {

	private Connection conn;
	private Statement stmt;
	private jdbc db;
	public ItemsHandler()
	{
		db=new jdbc();
		conn=db.getCon();
		stmt=null;
	}
	public void InsertRow(Vector<String> input) throws SQLException//���� ���� ���� ���� ���� ���� row�� ���� ���̺��� �߰�
	{
		stmt=conn.createStatement();
		String query="INSERT INTO Items(item_id, item_price, item_kind, item_stock) VALUES(";
		query=query+input.elementAt(0)+",'"+input.elementAt(1)+"','"+input.elementAt(2)+"','"+input.elementAt(3)+")";
		stmt.executeQuery(query);
			System.out.println(query+" Executed");
		stmt.close();
	}
	public void deleteRow(int num) throws SQLException// ���� ���̵� ���� ���� ���̵� ���� row�� ���� ���̺����� ����
	{
		stmt=conn.createStatement();
		String query="DELETE FROM Items WHERE item_id=";
		query=query+num;
		stmt.executeQuery(query);
		System.out.println(query+" Executed");
		stmt.close();
		
	}
	public void updateRow(int num, Vector<String> input) throws SQLException// ���� ���� ������ row update.query�� , �־��ִ� ��� �����ϱ�?=> , �� ������ ����� �� query�� �ν��� ���Ѵ�!
	{
		stmt=conn.createStatement();
		String query="UPDATE Items SET";
		for(int i=0;i<input.size();i++)
		{
			switch(i)
			{
			case 1:{
				if(!input.elementAt(i).equals(""))
				{
					query=query+" item_price='"+input.elementAt(i)+"'";
					int count=0;
					for(int j=i+1;j<input.size();j++)
					{
						if(!input.elementAt(j).equals(""))
							count++;
					}
					if(count!=0)
					{
						query=query+",";
					}
				
				}
				
				break;
			}
			case 2:
			{
				if(!input.elementAt(i).equals(""))
				{
					query=query+" item_kind='"+input.elementAt(i)+"'";
					int count=0;
					for(int j=i+1;j<input.size();j++)
					{
						if(!input.elementAt(j).equals(""))
							count++;
					}
					if(count!=0)
					{
						query=query+",";
					}
				}
				
				break;
			}
			case 3:
			{
				if(!input.elementAt(i).equals(""))
				{
					query=query+" item_stock='"+input.elementAt(i)+"'";
					if(!input.elementAt(4).equals(""))
					{
						query=query+",";
					}
				}
				break;
			}
			}
		}
		query=query+" WHERE item_id="+num;
		stmt.executeQuery(query);
		System.out.println(query+" Executed");
		stmt.close();
		
	}
	public Vector<Vector<String>> showAllItems() throws SQLException
	{
		
		Vector<Vector<String>> toRet=new Vector<>();
		stmt=conn.createStatement();
		ResultSet rs=stmt.executeQuery("SELECT* FROM Items");
		while(rs.next())
		{
			Vector<String> temp=new Vector<>();
			temp.add(rs.getString("item_id"));
			temp.add(rs.getString("item_price"));
			temp.add(rs.getString("item_kind"));
			temp.add(rs.getString("item_stock"));
			toRet.add(temp);
		}
		stmt.close();
		return toRet;
	}
	public Vector<Vector<String>> showByitem_price(String item_price) throws SQLException
	{
		
		Vector<Vector<String>> toRet=new Vector<>();
		stmt=conn.createStatement();
		ResultSet rs=stmt.executeQuery("SELECT* FROM Items WHERE item_price LIKE '"+item_price+"'");
		while(rs.next())
		{
			Vector<String> temp=new Vector<>();
			temp.add(rs.getString("item_id"));
			temp.add(rs.getString("item_price"));
			temp.add(rs.getString("item_kind"));
			temp.add(rs.getString("item_stock"));
			toRet.add(temp);
		}
		stmt.close();
		return toRet;
	}
	public Vector<Vector<String>> showByitem_kind(String item_kind) throws SQLException
	{
		
		Vector<Vector<String>> toRet=new Vector<>();
		stmt=conn.createStatement();
		ResultSet rs=stmt.executeQuery("SELECT* FROM Items WHERE item_kind LIKE '"+item_kind+"'");
		while(rs.next())
		{
			Vector<String> temp=new Vector<>();
			temp.add(rs.getString("item_id"));
			temp.add(rs.getString("item_price"));
			temp.add(rs.getString("item_kind"));
			temp.add(rs.getString("item_stock"));
			toRet.add(temp);
		}
		stmt.close();
		return toRet;
	}
	public Vector<Vector<String>> showByitem_stock(String item_stock) throws SQLException
	{
		
		Vector<Vector<String>> toRet=new Vector<>();
		stmt=conn.createStatement();
		ResultSet rs=stmt.executeQuery("SELECT* FROM Items WHERE owner='"+item_stock+"'");
		while(rs.next())
		{
			Vector<String> temp=new Vector<>();
			temp.add(rs.getString("item_id"));
			temp.add(rs.getString("item_price"));
			temp.add(rs.getString("item_kind"));
			temp.add(rs.getString("item_stock"));
			toRet.add(temp);
		}
		stmt.close();
		return toRet;
	}
	public Vector<Vector<String>> searchWithManyKeywords(Vector<String> input) throws SQLException
	{ 
		Vector<Vector<String>> toRet=new Vector<>();
		stmt=conn.createStatement();
		String query="SELECT* FROM Items WHERE ";
		for(int i=0;i<input.size();i++)
		{
			switch(i)
			{
			case 0:
			{
				if(!input.elementAt(i).equals(""))
				{
				query=query+"item_id="+input.elementAt(i);
				int count=0;
				for(int j=i+1;j<input.size();j++)
				{
					if(!input.elementAt(j).equals(""))
						count++;
				}
				if(count!=0)
				{
					query=query+"AND";
				}
				}
				break;
			}
			case 1:
			{
				if(!input.elementAt(i).equals(""))
				{
				query=query+"item_price="+input.elementAt(i);
				int count=0;
				for(int j=i+1;j<input.size();j++)
				{
					if(!input.elementAt(j).equals(""))
						count++;
				}
				if(count!=0)
				{
					query=query+"AND";
				}
				}
				break;
			}
			case 2:
			{
				if(!input.elementAt(i).equals(""))
				{
					query=query+"item_kind LIKE '"+input.elementAt(i)+"'";
					int count=0;
					for(int j=i+1;j<input.size();j++)
					{
						if(!input.elementAt(j).equals(""))
							count++;
					}
					if(count!=0)
					{
						query=query+"AND";
					}
				}				
				break;
			}
			case 3:
			{
				if(!input.elementAt(i).equals(""))
				{
				query=query+"item_stock="+input.elementAt(i);
				int count=0;
				for(int j=i+1;j<input.size();j++)
				{
					if(!input.elementAt(j).equals(""))
						count++;
				}
				if(count!=0)
				{
					query=query+"AND";
				}
				}
				break;
			}
			
			}
		}
		ResultSet rs=stmt.executeQuery(query);
		while(rs.next())
		{
			Vector<String> temp=new Vector<>();
			temp.add(rs.getString("item_id"));
			temp.add(rs.getString("item_price"));
			temp.add(rs.getString("item_kind"));
			temp.add(rs.getString("item_stock"));
			toRet.add(temp);
		}
		return toRet;
	}
	public void finalize() throws SQLException
	{
		stmt.close();
		conn.close();
	}
}
